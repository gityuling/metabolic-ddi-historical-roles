"""Train or evaluate the published MFPs classifier on MeTDDI UnseenDDIs."""
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import rdkit
import torch
from rdkit import Chem, DataStructs
from rdkit.Chem import AllChem
from sklearn.metrics import accuracy_score, auc, precision_recall_curve, roc_auc_score

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'upstream/interaction/src'))
from ddi_bench_mfps import DDINetwork


def load_split(device):
    paths = [ROOT / 'data' / f'{prefix}_dataset.csv' for prefix in ('tr', 'val', 'tst')]
    frames = [pd.read_csv(path) for path in paths]
    molecules = sorted({s for frame in frames for col in ('drug_A', 'drug_B') for s in frame[col]})
    indices = {s: i for i, s in enumerate(molecules)}
    fps = np.zeros((len(molecules), 2048), dtype=np.uint8)
    for i, smiles in enumerate(molecules):
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            raise ValueError(f'Invalid SMILES in fixed split: {smiles}')
        DataStructs.ConvertToNumpyArray(AllChem.GetMorganFingerprintAsBitVect(mol, 2, nBits=2048), fps[i])
    arrays = [np.column_stack([df.drug_A.map(indices), df.drug_B.map(indices), df.DDI]) for df in frames]
    if any(set(a[:, 2]) != set(range(4)) for a in arrays):
        raise ValueError('Expected MeTDDI four-class labels 0..3')
    pairs = [set(map(tuple, np.sort(a[:, :2], axis=1))) for a in arrays]
    info = dict(rows=[len(a) for a in arrays], molecules=len(molecules),
                train_test_pair_overlap=len(pairs[0] & pairs[2]),
                val_test_pair_overlap=len(pairs[1] & pairs[2]),
                sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    return (torch.tensor(fps, device=device, dtype=torch.float32),
            [torch.tensor(a, device=device) for a in arrays], info)


@torch.inference_mode()
def probabilities(model, fps, rows):
    model.eval()
    return torch.cat([model(fps[a], fps[b]).softmax(1) for a, b, _ in (chunk.T for chunk in rows.split(1024))])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--eval-only', action='store_true')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    out = args.output or ROOT / f'run_seed{args.seed}'
    out.mkdir(parents=True, exist_ok=True)
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    torch.manual_seed(args.seed)
    torch.set_float32_matmul_precision('high')
    fp, (train, valid, test), info = load_split(device)
    model = DDINetwork(2048, 512, 256, 4, 0.3).to(device)
    ckpt = out / 'best.pt'
    if not args.eval_only:
        optimizer = torch.optim.Adam(model.parameters(), lr=1e-4, fused=device == 'cuda')
        best = -1
        start = time.perf_counter()
        for epoch in range(1, args.epochs + 1):
            model.train()
            for rows in train[torch.randperm(len(train), device=device)].split(512):
                a, b, y = rows.T
                optimizer.zero_grad(set_to_none=True)
                loss = torch.nn.functional.cross_entropy(model(fp[a], fp[b]), y)
                loss.backward()
                optimizer.step()
            val_acc = (probabilities(model, fp, valid).argmax(1) == valid[:, 2]).float().mean().item()
            if val_acc > best:
                best = val_acc
                torch.save(dict(model=model.state_dict(), epoch=epoch, validation_accuracy=best, data=info), ckpt)
            if epoch == 1 or epoch % 10 == 0:
                print(f'epoch={epoch} val_acc={val_acc:.5f} seconds={time.perf_counter()-start:.1f}', flush=True)
        (out / 'training.json').write_text(json.dumps(dict(seed=args.seed, epochs=args.epochs,
            seconds=time.perf_counter()-start, torch=str(torch.__version__), rdkit=rdkit.__version__,
            device=torch.cuda.get_device_name() if device=='cuda' else device),indent=2))
    state = torch.load(ckpt, map_location=device, weights_only=True)
    assert state['data'] == info, 'Data changed since training'
    model.load_state_dict(state['model'])
    p = probabilities(model, fp, test).cpu().numpy()
    y = test[:, 2].cpu().numpy()
    hot = np.eye(4)[y]
    pr = [precision_recall_curve(hot[:, i], p[:, i]) for i in range(4)]
    result = dict(accuracy=accuracy_score(y,p.argmax(1)), macro_auroc=roc_auc_score(hot,p),
                  macro_aupr=np.mean([auc(r,prec) for prec,r,_ in pr]), best_epoch=state['epoch'],
                  validation_accuracy=state['validation_accuracy'], data=info)
    np.savez_compressed(out/'predictions.npz', labels=y, probabilities=p)
    (out/'metrics.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result),flush=True)


if __name__ == '__main__':
    main()
