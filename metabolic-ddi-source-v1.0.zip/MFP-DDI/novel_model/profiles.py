from pathlib import Path
import sys
import torch
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from run import load_split

def graph(n, rows):
    a,b,y=rows.T
    G=torch.zeros((4,n,n),device=rows.device)
    G[y,a,b]=1
    G[(y+2)%4,b,a]=1
    return G

def similarity(G):
    mask=G.sum(0).clamp(max=1)
    common=mask@mask.T
    match=(G@G.transpose(1,2)).sum(0)
    return ((match+0.2)/(common+1)).fill_diagonal_(0),common

def votes(G,sim,common,power,smoothing):
    W=(sim*common/(common+smoothing)).pow(power)
    score=W@G
    reverse=score[[2,3,0,1]].transpose(1,2)
    return score+reverse

def novel_valid(train,valid,n):
    seen=set((train[:,0]*n+train[:,1]).tolist())
    keep=[int(a)*n+int(b) not in seen and int(b)*n+int(a) not in seen for a,b,_ in valid.tolist()]
    return valid[keep]

if __name__=='__main__':
    fp,(train,valid,_),_=load_split('cuda')
    a,b,y=novel_valid(train,valid,len(fp)).T
    G=graph(len(fp),train)
    sim,common=similarity(G)
    for p in [4,8,16,32]:
        for sm in [1,5,15]:
            pred=votes(G,sim,common,p,sm)[:,a,b].T
            print(p,sm,(pred.argmax(1)==y).float().mean().item())
