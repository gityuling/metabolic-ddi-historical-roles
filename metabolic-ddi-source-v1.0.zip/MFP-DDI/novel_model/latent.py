"""Cross-fitted low-rank and cluster-conditional estimates of directional interaction counts."""
import sys
import numpy as np
import torch
from profiles import graph,load_split,novel_valid
from neighbors import ROOT

def partition(v,k):
    rng=torch.Generator(device=v.device).manual_seed(52+k)
    c=v[torch.randperm(len(v),generator=rng,device=v.device)[:k]]
    for _ in range(25):
        ix=torch.cdist(v,c).argmin(1)
        one=torch.nn.functional.one_hot(ix,k).float()
        sizes=one.sum(0)
        c=torch.where(sizes[:,None]>0,(one.T@v)/sizes.clamp(min=1)[:,None],c)
    return one

def features(fp,edges,rows):
    n=len(fp);g=graph(n,edges)
    a,b=rows[:,:2].T
    flat=g.permute(1,0,2).reshape(n,-1)
    binary=g.sum(0)
    deg=binary.sum(1).clamp(min=1)
    x=[]
    for norm in (0,.5):
        gn=g/(deg[:,None]*deg[None,:]).pow(norm)
        flat=gn.permute(1,0,2).reshape(n,-1)
        gram=flat@flat.T
        eig,v=torch.linalg.eigh(gram)
        eig=eig.flip([0]).clamp(min=0);v=v.flip([1])
        for k in [4,12,32,64,128]:
            u=v[:,:k]
            gleft=u@(u.T@gn)
            gboth=(gleft@u)@u.T
            x.extend([gleft[:,a,b].T,gleft[:,b,a].T,gboth[:,a,b].T])
        emb=v[:,:48]*eig[:48].pow(.25)
        emb=torch.nn.functional.normalize(emb)
        for k in (16,40,100,240):
            groups=partition(emb,k)
            counts=g@groups
            for i,j in ((a,b),(b,a)):
                x.append(counts[:,i,groups[j].argmax(1)].T)
            block=groups.T@counts
            gi,gj=groups[a].argmax(1),groups[b].argmax(1)
            x.append(block[:,gi,gj].T)
    return torch.cat(x,1).cpu().numpy()

def main(which):
    fp,(tr,va,te),_=load_split('cuda')
    a,b,y=tr.T
    can=torch.stack((a.minimum(b),a.maximum(b),torch.where(a<=b,y,(y+2)%4)),1).unique(dim=0)
    def save(name,history,rows):
        rev=rows[:,[1,0,2]].clone();rev[:,2]=(rev[:,2]+2)%4
        np.save(ROOT/f'{name}_latent.npy',features(fp,history,torch.cat((rows,rev))))
    if which=='prepare':
        torch.manual_seed(1457)
        folds=torch.randperm(len(can),device='cuda').tensor_split(8)
        for i,hold in enumerate(folds):
            save(f'fold{i}',can[torch.cat([f for j,f in enumerate(folds) if i!=j])],can[hold])
        save('valid',can,novel_valid(tr,va,len(fp)))
    else:
        save('test',can,te[np.load(ROOT.parent/'data/novel_test_indices.npy')])
if __name__=='__main__':main(sys.argv[1])
