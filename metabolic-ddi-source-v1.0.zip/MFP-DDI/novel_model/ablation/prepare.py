"""Build direction-masked graph features with the frozen training fold assignments."""
from pathlib import Path
import sys
from unittest.mock import patch
import numpy as np
import torch

OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT.parent))
import neighbors,latent,kernel
from profiles import graph,load_split,novel_valid
from relation import canonicalize

def blind_graph(n,edges):
    # Independent of the role bit y//2. Preserve the total weight of one edge.
    a,b,y=edges.T
    effect=y%2
    g=torch.zeros((4,n,n),device=edges.device)
    for k in (effect,effect+2):
        g[k,a,b]=.5
        g[k,b,a]=.5
    return g

def main():
    fp,(tr,va,te),info=load_split('cuda')
    np.save(OUT/'fp.npy',fp.cpu().numpy().astype('uint8'))
    can=canonicalize(tr)
    torch.manual_seed(1457)
    folds=torch.randperm(len(can),device='cuda').tensor_split(8)
    def save(name,h,q):
        rev=q[:,[1,0,2]].clone();rev[:,2]=(rev[:,2]+2)%4
        rows=torch.cat((q,rev))
        expected=np.load(OUT.parent/f'{name}.npz')['y']
        np.testing.assert_array_equal(rows[:,2].cpu().numpy(),expected)
        assert not set(map(tuple,torch.sort(h[:,:2],1).values.tolist())) & set(map(tuple,torch.sort(q[:,:2],1).values.tolist()))
        g=blind_graph(len(fp),h)
        assert torch.equal(g,g.transpose(1,2)) and torch.equal(g[:2],g[2:])
        assert torch.equal(g.sum(0),graph(len(fp),h).sum(0))
        parts=[]
        for module in (neighbors,latent,kernel):
            with patch.object(module,'graph',blind_graph):
                parts.append(module.features(fp,h,rows))
        np.save(OUT/f'{name}_blind.npy',np.column_stack(parts))
        np.save(OUT/f'{name}_rows.npy',rows.cpu().numpy())
        print(name,flush=True)
    for i,hold in enumerate(folds):
        save(f'fold{i}',can[torch.cat([f for j,f in enumerate(folds) if j!=i])],can[hold])
    save('valid',can,novel_valid(tr,va,len(fp)))
    save('test',can,te[np.load(OUT.parent.parent/'data/novel_test_indices.npy')])
if __name__=='__main__':main()
