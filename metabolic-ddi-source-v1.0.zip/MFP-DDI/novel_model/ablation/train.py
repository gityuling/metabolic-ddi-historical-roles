"""Matched CatBoost fits: only the information given to the classifier changes."""
import argparse
import json
import sys
from pathlib import Path
import numpy as np
from scipy import sparse
from catboost import Pool,CatBoostClassifier
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT.parent))
from boost import data_for

def dataset(names,arm):
    rows=np.concatenate([np.load(OUT/f'{name}_rows.npy') for name in names])
    parts=[]
    if arm!='blind_original':
        fp=sparse.csr_matrix(np.load(OUT/'fp.npy'),dtype=np.float32)
        parts.extend([fp[rows[:,i]] for i in (0,1)])
    if arm!='fp':
        def network(name):
            if arm=='full':
                return data_for(name,True,True)['x']
            return np.load(OUT/f'{name}_blind.npy')
        graph=np.concatenate([network(n) for n in names])
        if arm=='blind_original':
            return Pool(graph,label=rows[:,2],thread_count=5),rows[:,2]
        parts.append(sparse.csr_matrix(graph))
    return Pool(sparse.hstack(parts,format='csr'),label=rows[:,2],thread_count=5),rows[:,2]

def sym(p):
    a,b=np.split(p,2)
    return (a+b[:,[2,3,0,1]])/2

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('arm',choices=['fp','blind','full','blind_original'])
    ap.add_argument('--seed',type=int,choices=range(5))
    args=ap.parse_args()
    folder=OUT/args.arm
    folder.mkdir(exist_ok=True)
    train,_=dataset([f'fold{i}' for i in range(8)],args.arm)
    valid,y=dataset(['valid'],args.arm)
    y=np.split(y,2)[0]
    print(args.arm,train.num_row(),train.num_col(),flush=True)
    for seed in (range(5) if args.seed is None else [args.seed]):
        model=CatBoostClassifier(iterations=1400,depth=7,learning_rate=.09,random_seed=seed,
                task_type='GPU',devices='0',thread_count=5,verbose=False,allow_writing_files=False)
        model.fit(train,eval_set=valid,use_best_model=False)
        scores=[float(np.mean(sym(p).argmax(1)==y)) for p in model.staged_predict_proba(valid,eval_period=100,thread_count=5)]
        trees=100*(1+int(np.argmax(scores)))
        model.shrink(trees)
        model.save_model(str(folder/f'{seed}.cbm'))
        (folder/f'{seed}_selection.json').write_text(json.dumps(dict(seed=seed,trees=trees,val_scores=scores)))
        print(seed,trees,max(scores),flush=True)
if __name__=='__main__':main()
