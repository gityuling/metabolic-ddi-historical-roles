"""Local kernel ridge predictors conditioned on each drug's known partners."""
import sys
import numpy as np
import torch
from neighbors import ROOT
from profiles import graph, load_split, novel_valid
from relation import canonicalize

def features(fp,edges,rows):
    a,b=rows[:,:2].T
    n=len(fp);g=graph(n,edges);mask=g.sum(0)
    deg=mask.sum(1)
    d=fp@fp.T
    chem=d/(fp.sum(1)[:,None]+fp.sum(1)[None,:]-d).clamp_min(1)
    flat=g.transpose(0,1).reshape(n,-1)
    prof=torch.nn.functional.normalize(flat)
    cos=prof@prof.T
    com=mask@mask.T
    jac=com/(deg[:,None]+deg[None,:]-com).clamp_min(1)
    out=[]
    # Bucket rows with a similar number of known partners for batched linear solves.
    count=mask.sum(1).long()
    ix=torch.argsort(mask,1,descending=True)
    for k in (cos,cos.pow(2),jac,.5*cos+.5*chem, .5*cos+.5*jac):
        for reg in (.04,.4):
            scores=torch.zeros((n,4,n),device=fp.device)
            for lo in range(0,int(count.max())+1,32):
                group=torch.where((count>lo)&(count<=lo+32))[0]
                for drug in group.split(64):
                    if not len(drug):continue
                    size=lo+32
                    ids=ix[drug,:size]
                    valid=mask[drug[:,None],ids]
                    kernel=k[ids[:,:,None],ids[:,None,:]]*valid[:,:,None]*valid[:,None,:]
                    kernel.diagonal(dim1=1,dim2=2).add_(reg)
                    target=g[:,drug[:,None],ids].permute(1,2,0)
                    coef=torch.linalg.solve(kernel,target)
                    scores[drug]=coef.transpose(1,2)@(k[ids]*valid[:,:,None])
            out.extend((scores[a,:,b],scores[b,:,a]))
    return torch.cat(out,1).cpu().numpy()

def main(mode):
    fp,(tr,va,te),_=load_split('cuda');can=canonicalize(tr)
    def save(name,h,r):
        rev=r[:,[1,0,2]].clone();rev[:,2]=(rev[:,2]+2)%4
        np.save(ROOT/f'{name}_kernel.npy',features(fp,h,torch.cat((r,rev))))
    if mode=='prepare':
        torch.manual_seed(1457)
        folds=torch.randperm(len(can),device='cuda').tensor_split(8)
        for i,hold in enumerate(folds):
            save(f'fold{i}',can[torch.cat([f for j,f in enumerate(folds) if i!=j])],can[hold])
        save('valid',can,novel_valid(tr,va,len(fp)))
    else:save('test',can,te[np.load(ROOT.parent/'data/novel_test_indices.npy')])
if __name__=='__main__':main(sys.argv[1])
