"""Train an interaction-profile encoder with whole-pair masking."""
import argparse
import json
import time
from pathlib import Path

import torch
from torch import nn
import numpy as np
from profiles import load_split, graph, novel_valid

ROOT=Path(__file__).resolve().parent

class ProfileModel(nn.Module):
    def __init__(self,n):
        super().__init__()
        self.profile=nn.Sequential(nn.Linear(4*n,512),nn.LayerNorm(512),nn.GELU(),nn.Dropout(.15),nn.Linear(512,256))
        self.chem=nn.Sequential(nn.Linear(2048,256),nn.LayerNorm(256),nn.GELU(),nn.Linear(256,128))
        self.head=nn.Sequential(nn.Linear(384,384),nn.LayerNorm(384),nn.GELU(),nn.Dropout(.1),nn.Linear(384,4*96))
        self.bias=nn.Linear(384,4)

    def encode(self,G,fp):
        features=G.transpose(0,1).reshape(len(fp),-1)
        features=features/(features.sum(1,keepdim=True)+1).sqrt()
        z=torch.cat((self.profile(features),self.chem(fp)),dim=1)
        return self.head(z).reshape(-1,2,2,96),self.bias(z).reshape(-1,2,2)

    def forward(self,encoded,rows):
        h,bias=encoded
        a,b=rows[:,:2].T
        def score(a,b):
            return (h[a,0]*h[b,1]).sum(-1)/96**.5+bias[a,0]+bias[b,1]
        return torch.cat((score(a,b),score(b,a)),dim=-1)

@torch.no_grad()
def probabilities(model,G,fp,rows):
    model.eval()
    z=model.encode(G,fp)
    return torch.cat([model(z,chunk).softmax(1) for chunk in rows.split(4096)])

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('mode',choices=['fit','evaluate'])
    ap.add_argument('--seed',type=int,required=True)
    ap.add_argument('--steps',type=int,default=2400)
    args=ap.parse_args()
    torch.manual_seed(args.seed)
    torch.set_float32_matmul_precision('high')
    fp,(tr,va,te),info=load_split('cuda')
    n=len(fp)
    # Canonicalize orientation before sampling so no held-out edge remains in reverse.
    a,b,y=tr.T
    canonical=torch.stack((a.minimum(b),a.maximum(b),torch.where(a<=b,y,(y+2)%4)),1).unique(dim=0)
    assert len(canonical[:,:2].unique(dim=0))==len(canonical)
    val=novel_valid(tr,va,n)
    full=graph(n,canonical)
    model=ProfileModel(n).cuda()
    out=ROOT/f'seed{args.seed}'
    out.mkdir(exist_ok=True)
    if args.mode=='fit':
        start=time.perf_counter()
        opt=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.01,fused=True)
        sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,args.steps,eta_min=.00007)
        best=0
        for step in range(1,args.steps+1):
            model.train()
            # Each step holds out a random 20% of training pairs from both profile directions.
            perm=torch.randperm(len(canonical),device='cuda')
            hidden=canonical[perm[:len(perm)//5]]
            G=full.clone()
            a,b,y=hidden.T
            G[y,a,b]=0
            G[(y+2)%4,b,a]=0
            rows=hidden[:8192]
            loss=nn.functional.cross_entropy(model(model.encode(G,fp),rows),rows[:,2])
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
            sched.step()
            if step%50==0:
                acc=(probabilities(model,full,fp,val).argmax(1)==val[:,2]).float().mean().item()
                if acc>best:
                    best=acc
                    torch.save(dict(model=model.state_dict(),step=step,val=acc,sha256=info['sha256']),out/'best.pt')
                if step%200==0: print(step,acc,best,round(time.perf_counter()-start,1),flush=True)
        (out/'training.json').write_text(json.dumps(dict(seed=args.seed,seconds=time.perf_counter()-start,best=best,steps=args.steps)))
    else:
        s=torch.load(out/'best.pt',weights_only=True)
        assert s['sha256']==info['sha256']
        model.load_state_dict(s['model'])
        p=probabilities(model,full,fp,te).cpu().numpy()
        np.savez_compressed(out/'predictions.npz',labels=te[:,2].cpu().numpy(),probabilities=p)

if __name__=='__main__':
    main()
