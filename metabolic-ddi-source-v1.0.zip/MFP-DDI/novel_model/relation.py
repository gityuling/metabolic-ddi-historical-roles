"""Masked relational message passing with auxiliary edge reconstruction."""
import argparse
import numpy as np
import torch
from torch import nn

from profiles import graph, load_split, novel_valid
from denoise import ROOT

class Relational(nn.Module):
    def __init__(self,n):
        super().__init__()
        self.identity=nn.Parameter(torch.randn(n,64)*.1)
        self.mol=nn.Sequential(nn.Linear(2048,256),nn.LayerNorm(256),nn.GELU(),nn.Linear(256,128))
        self.conv=nn.Sequential(nn.Linear(192*4,256),nn.LayerNorm(256),nn.GELU(),nn.Linear(256,128))
        self.role=nn.Sequential(nn.Linear(320,256),nn.LayerNorm(256),nn.GELU(),nn.Dropout(.12),nn.Linear(256,256))
        self.bias=nn.Linear(320,4)

    def encode(self,fp,edges):
        g=graph(len(fp),edges)
        z=torch.cat((self.mol(fp),self.identity),1)
        msg=((g@z)/(1+g.sum(2,keepdim=True)).sqrt()).transpose(0,1).reshape(len(fp),-1)
        z=torch.cat((z,self.conv(msg)),1)
        return self.role(z).reshape(-1,2,2,64),self.bias(z).reshape(-1,2,2)

    def forward(self,z,rows):
        h,bi=z
        a,b=rows[:,:2].T
        def direction(i,j):
            return (h[i,0]*h[j,1]).sum(-1)/8+bi[i,0]+bi[j,1]
        return torch.cat((direction(a,b),direction(b,a)),1)

@torch.no_grad()
def pred(model,fp,history,rows):
    model.eval();z=model.encode(fp,history)
    return torch.cat([model(z,r).softmax(1) for r in rows.split(4096)])

def canonicalize(tr):
    a,b,y=tr.T
    return torch.stack((a.minimum(b),a.maximum(b),torch.where(a<=b,y,(y+2)%4)),1).unique(dim=0)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--seed',type=int,default=0)
    args=p.parse_args()
    torch.manual_seed(args.seed);torch.set_float32_matmul_precision('high')
    fp,(tr,va,_),_=load_split('cuda')
    va=novel_valid(tr,va,len(fp));can=canonicalize(tr)
    negative=torch.stack(torch.where(torch.triu(graph(len(fp),tr).sum(0)==0,diagonal=1)),1)
    model=Relational(len(fp)).cuda()
    opt=torch.optim.AdamW(model.parameters(),lr=.0015,weight_decay=.015,fused=True)
    steps=4000
    sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,steps,eta_min=.0001)
    best=0
    for t in range(1,steps+1):
        model.train()
        idx=torch.randperm(len(can),device='cuda')
        rows=can[idx[:8192]]
        z=model.encode(fp,can[idx[16384:]])
        logits=model(z,rows)
        neg=model(z,negative[torch.randint(len(negative),(8192,),device='cuda')])
        loss=nn.functional.cross_entropy(logits,rows[:,2])+.3*(nn.functional.softplus(-logits.logsumexp(1)).mean()+nn.functional.softplus(neg.logsumexp(1)).mean())
        opt.zero_grad(set_to_none=True);loss.backward();opt.step();sched.step()
        if t%50==0:
            probs=pred(model,fp,can,va)
            acc=(probs.argmax(1)==va[:,2]).float().mean().item()
            if acc>best:
                best=acc
                torch.save(model.state_dict(),ROOT/f'rel{args.seed}.pt')
                np.save(ROOT/f'rel{args.seed}_valid.npy',probs.cpu().numpy())
            if t%500==0:print(t,acc,best,flush=True)
if __name__=='__main__':main()
