import argparse
from pathlib import Path

import numpy as np
from catboost import CatBoostClassifier

ROOT=Path(__file__).resolve().parent

def infer(model,data,ntree_end=0):
    a,b=np.split(model.predict_proba(data['x'],ntree_end=ntree_end),2)
    return (a+b[:,[2,3,0,1]])/2

def data_for(name,latent,kernel=False):
    with np.load(ROOT/f'{name}.npz') as data:
        x,y=data['x'],data['y']
    if latent:
        x=np.column_stack([x,np.load(ROOT/f'{name}_latent.npy')])
    if kernel:
        x=np.column_stack([x,np.load(ROOT/f'{name}_kernel.npy')])
    return dict(x=x,y=y)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--seed',type=int,required=True)
    ap.add_argument('--latent',action='store_true')
    ap.add_argument('--kernel',action='store_true')
    args=ap.parse_args()
    if args.kernel and not args.latent:
        ap.error('--kernel requires --latent')
    prefix='latentboost' if args.latent else 'boost'
    if args.kernel:
        prefix='kernelboost'
    files=[data_for(f'fold{i}',args.latent,args.kernel) for i in range(8)]
    x=np.concatenate([v['x'] for v in files])
    y=np.concatenate([v['y'] for v in files])
    val=data_for('valid',args.latent,args.kernel)
    model=CatBoostClassifier(iterations=1400, depth=7, learning_rate=.09, random_seed=args.seed,
                             task_type='GPU',devices='0',thread_count=5,verbose=200,allow_writing_files=False)
    model.fit(x,y,eval_set=(val['x'],val['y']),use_best_model=False)
    target=np.split(val['y'],2)[0]
    best=0
    for end in range(100,1401,100):
        p=infer(model,val,end)
        acc=np.mean(p.argmax(1)==target)
        if acc>best:
            best=acc
            chosen=end
            np.save(ROOT/f'{prefix}{args.seed}_valid.npy',p)
    model.shrink(chosen)
    model.save_model(str(ROOT/f'{prefix}{args.seed}.cbm'))
    print('validation',best,'trees',chosen)
if __name__=='__main__':
    main()
