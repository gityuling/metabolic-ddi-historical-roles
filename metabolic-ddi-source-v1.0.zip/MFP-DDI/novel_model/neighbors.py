"""Features from labeled training interactions, estimated out of fold by unordered pair."""
import argparse
import time
import json
from pathlib import Path
import numpy as np
import torch

from profiles import graph, load_split, novel_valid

ROOT=Path(__file__).resolve().parent

def features(fp, edges, queries):
    n=len(fp)
    g=graph(n,edges)
    a,b=queries[:,:2].T
    mask=g.sum(0)
    deg=mask.sum(1)
    ca=g.sum(2)
    cols=[ca[:,a].T,ca[:,b].T]
    shared=mask@mask.T
    matches=(g@g.transpose(1,2)).sum(0)
    dots=fp@fp.T
    tan=dots/(fp.sum(1)[:,None]+fp.sum(1)-dots).clamp(min=1)
    cos=matches/(deg[:,None]*deg[None,:]).clamp(min=1).sqrt()
    agreement=(matches+.1)/(shared+1)
    union=deg[:,None]+deg[None,:]-shared
    jac=shared/union.clamp(min=1)
    gflat=g.permute(1,0,2).reshape(n,-1).contiguous()
    for x in g:
        for z in g:
            cols.append((x@z.T)[a,b].unsqueeze(1))
    cols.extend([mat[a,b].unsqueeze(1) for mat in (tan,shared,matches,jac,cos)])
    # Candidates are drugs with known interactions with the opposite endpoint.
    for sim in (tan,cos,agreement*shared/(shared+5),jac,cos*(.2+.8*agreement)):
        sim=sim.fill_diagonal_(0).clamp(0,1)
        for power in [2,8,24,64]:
            weight=sim.pow(power)
            score=(weight@gflat).reshape(n,4,n)
            for i,j in ((a,b),(b,a)):
                cols.append(score[i,:,j].clamp(min=1e-30).log())
        # Maximum similarity of any supporting example of each class.
        for start in [0]:  # collect extrema in chunks to bound temporary GPU use
            blocks=[]
            for i,j in ((a,b),(b,a)):
                blocks.clear()
                for ii,jj in zip(i.split(1024),j.split(1024)):
                    v=sim[ii,None,:]*g[:,:,jj].permute(2,0,1)
                    blocks.append(v.topk(2,dim=-1).values.flatten(1))
                cols.append(torch.cat(blocks))
    return torch.cat(cols,1).cpu().numpy()

def prepare(mode):
    fp,(train,valid,test),info=load_split('cuda')
    a,b,y=train.T
    canonical=torch.stack((a.minimum(b),a.maximum(b),torch.where(a<=b,y,(y+2)%4)),1).unique(dim=0)
    cfg=dict(sha256=info['sha256'],fold_seed=1457,folds=8)
    def cache(name,history,rows):
        # Write both directions; role-swapped averaging at inference.
        rev=rows[:,[1,0,2]].clone()
        rev[:,2]=(rev[:,2]+2)%4
        x=features(fp,history,torch.cat((rows,rev)))
        np.savez(ROOT/f'{name}.npz',x=x,y=torch.cat((rows[:,2],rev[:,2])).cpu().numpy())
    if mode=='prepare':
        torch.manual_seed(cfg['fold_seed'])
        folds=torch.randperm(len(canonical),device='cuda').tensor_split(cfg['folds'])
        for i,hold in enumerate(folds):
            history=canonical[torch.cat([f for j,f in enumerate(folds) if i!=j])]
            cache(f'fold{i}',history,canonical[hold]);print('fold',i,flush=True)
        cache('valid',canonical,novel_valid(train,valid,len(fp)))
        (ROOT/'feature_config.json').write_text(json.dumps(cfg,indent=2))
    else:
        assert json.loads((ROOT/'feature_config.json').read_text())==cfg
        idx=np.load(ROOT.parent/'data/novel_test_indices.npy')
        cache('test',canonical,test[idx])
if __name__=='__main__':
    import sys
    prepare(sys.argv[1])
