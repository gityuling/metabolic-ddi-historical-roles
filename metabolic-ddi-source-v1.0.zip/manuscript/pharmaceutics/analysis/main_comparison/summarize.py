"""Pair-level evaluation with aligned opposite orders and paired seed-mean bootstrap intervals."""
from common import *
import json, sys
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, precision_recall_curve, auc

def metrics(f,p):
    np.testing.assert_allclose(p.sum(1),1,atol=2e-6); assert np.isfinite(p).all() and p.min()>=0
    y=f.y.to_numpy();role=f.role.to_numpy()
    a=p[:,:2].sum(1); b=p[:,2:].sum(1); role_hat=(b>a).astype(int)
    tied=np.where(a==b)[0]
    if len(tied):role_hat[tied]=[int(tied_choice(f.a.iloc[i])>tied_choice(f.b.iloc[i])) for i in tied]
    values={'role_accuracy':(role==role_hat).mean()}
    if min(y)<0: return values,(role==role_hat).astype(float)
    y=np.r_[y,(y+2)%4]; p=np.vstack((p,p[:,[2,3,0,1]])); h=p.argmax(1)
    hot=np.eye(4)[y]; curves=[precision_recall_curve(hot[:,i],p[:,i]) for i in range(4)]
    values.update(accuracy=(h==y).mean(),macro_f1=f1_score(y,h,average='macro'),macro_auroc=roc_auc_score(hot,p),
                  macro_aupr=np.mean([auc(r,pr) for pr,r,_ in curves]),role_error=(h//2!=y//2).mean())
    return values,(h==y).reshape(2,-1).mean(0)

