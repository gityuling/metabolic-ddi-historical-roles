"""DDIMDL history adapter over the existing Ours graph representation."""
from prepare import HERE
from common import *
import torch, sys, json
from rdkit.Chem import AllChem
sys.path[:0]=[str(BASE),str(BASE/'novel_model'),str(BASE/'novel_model/.deps')]
import neighbors, latent, kernel
from catboost import CatBoostClassifier
from sklearn.metrics import log_loss
from sklearn.linear_model import LogisticRegression
SWAP=[2,3,0,1]
def fold_id(key,n):
    return int(hashlib.sha256(key.encode()).hexdigest()[:10],16)%n

def features(fp,edges,rows,feature_modules=(neighbors,latent,kernel)):
    query=torch.cat([rows,rows[:,[1,0,2]]])
    return np.column_stack([x.features(fp,edges,query) for x in feature_modules])

def log_features(vectors):
    blocks=[]
    for p in vectors:
        lp=np.log(np.clip(p,1e-6,1))
        blocks.append(lp-lp.mean(1,keepdims=True))
    return np.column_stack(blocks)

def fit_combiner(ps,y):
    x=log_features(ps); xr=log_features([p[:,SWAP] for p in ps])
    return LogisticRegression(C=.1,max_iter=2000).fit(np.vstack((x,xr)),np.r_[y,(y+2)%4])

def apply_combiner(model,qs):
    p=model.predict_proba(log_features(qs))
    r=model.predict_proba(log_features([q[:,SWAP] for q in qs]))
    return (p+r[:,SWAP])/2

def catalog(df):
    # Use release structures for similarity, one node per parent-connectivity key.
    mols={}
    for r in df.itertuples():
        for key,s in zip(r.key.split('|'),[r.a,r.b]):
            mols.setdefault(key,set()).add(s)
    names=sorted(mols); ids={k:i for i,k in enumerate(names)}
    # Canonical representative chosen independently of labels.
    fp=torch.tensor(np.stack([np.asarray(AllChem.GetMorganFingerprintAsBitVect(Chem.MolFromSmiles(min(mols[k])),2,nBits=2048)) for k in names]),device='cuda',dtype=torch.float32)
    arr=torch.tensor([[*[ids[k] for k in r.key.split('|')],r.y if r.split=='history' else 0] for r in df.itertuples()],device='cuda')
    return ids,fp,arr

def make_features(df,feature_modules=(neighbors,latent,kernel)):
    _,fp,arr=catalog(df)
    hist=np.where(df.split=='history')[0]; rest=np.where(df.split!='history')[0]
    folds=np.array([fold_id(k,5) for k in df.key[hist]])
    feats=[]; labels=[]
    for k in range(5):
        keep=hist[folds!=k]; held=hist[folds==k]
        feats.append(features(fp,arr[keep],arr[held],feature_modules)); y=df.y.to_numpy()[held]
        labels.extend(np.r_[y,(y+2)%4])
    return np.vstack(feats),np.array(labels),features(fp,arr[hist],arr[rest],feature_modules),rest
def fit(folder=HERE):
    df=pd.read_csv(folder/'pairs.csv')
    x,y,ext,rest=make_features(df); sel=df.split.to_numpy()[rest]=='calibration'
    label=df.y.to_numpy()[rest][sel]; cfg=[]
    for seed in range(5):
        m=CatBoostClassifier(iterations=600,depth=5,learning_rate=.07,random_seed=seed,thread_count=4,verbose=False,allow_writing_files=False)
        m.fit(x,y);best=np.inf
        for trees in range(100,601,100):
            ix=np.r_[np.flatnonzero(sel),np.flatnonzero(sel)+len(rest)]
            u,v=np.split(m.predict_proba(ext[ix],ntree_end=trees),2)
            loss=log_loss(label,(u+v[:,SWAP])/2,labels=[0,1,2,3])
            if loss<best:best=loss;chosen=trees
        m.shrink(chosen);m.save_model(str(folder/f'head{seed}.cbm'))
        u,v=np.split(m.predict_proba(ext),2);np.save(folder/f'history{seed}.npy',(u+v[:,SWAP])/2)
        cfg.append({'seed':seed,'trees':chosen,'calibration_logloss':best});print(cfg[-1],flush=True)
    (folder/'heads.json').write_text(json.dumps(cfg,indent=2))
if __name__=='__main__':fit(HERE/'deepddi' if '--deepddi' in sys.argv else HERE)
