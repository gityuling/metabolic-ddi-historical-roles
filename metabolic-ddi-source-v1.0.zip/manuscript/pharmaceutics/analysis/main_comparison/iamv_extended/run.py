"""Fit the MeTDDI IAMV-DDI adaptation with a larger validation-selected budget."""
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import torch

OUT = Path(__file__).resolve().parent
MC = OUT.parent
sys.path.insert(0, str(MC))
from common import native, reduced
from iamv import DDIHead, Drugs, train_heads
from summarize import metrics

MAX_EPOCHS = 150
MIN_EPOCHS = 100
PATIENCE = 5


def main():
    if not torch.cuda.is_available():
        raise RuntimeError('This fitting pipeline requires a CUDA device')
    splits, _ = native()
    train = reduced(splits[0])
    used = {(a, b) for a, b, _ in train}
    valid = [row for row in reduced(splits[1]) if row[:2] not in used]
    drugs = Drugs(native_only=True)
    fit, val = drugs.rows(train), drugs.rows(valid)
    print('GPU:', torch.cuda.get_device_name(), 'fitting pairs:', len(fit),
          'validation pairs:', len(val), flush=True)
    print('Maximum epochs:', MAX_EPOCHS, 'minimum epochs:', MIN_EPOCHS,
          'validation patience:', PATIENCE, flush=True)
    train_heads(drugs, fit, val, OUT, max_epochs=MAX_EPOCHS,
                min_epochs=MIN_EPOCHS, patience=PATIENCE)
    del drugs

    # Select checkpoints by validation accuracy before evaluating the test pairs.
    results = []
    for seed in range(5):
        trace = json.loads((OUT/f'iamv_history{seed}.json').read_text())
        best = max(trace, key=lambda row: row['val_accuracy'])
        results.append(dict(seed=seed, best_epoch=best['epoch'], val_accuracy=best['val_accuracy']))

    rows = pd.read_csv(MC/'scored_pairs.csv')
    mask = rows.source.eq('MeTDDI')
    test = rows.loc[mask]
    assert len(test) == 6904
    drugs = Drugs()
    query = drugs.rows(list(rows[['a', 'b', 'y']].itertuples(index=False, name=None)))
    model = DDIHead(num_rel=4).cuda()
    for result in results:
        seed = result['seed']
        path = OUT/f'iamv{seed}.pt'
        model.load_state_dict(torch.load(path, weights_only=True, map_location='cpu'))
        p = drugs.predict(model, query)[mask.to_numpy()]
        assert p.shape == (len(test),4)
        np.save(OUT/f'predictions{seed}.npy',p)
        values, _ = metrics(test, p)
        result.update(test_accuracy=values['accuracy'])
        print(result, flush=True)

    manifest = dict(state='complete', dataset='MeTDDI', max_epochs=MAX_EPOCHS,
                    min_epochs=MIN_EPOCHS, patience_checks=PATIENCE,
                    validation_interval=5, gpu=torch.cuda.get_device_name(), runs=results)
    temporary = OUT/'report.tmp'
    temporary.write_text(json.dumps(manifest, indent=2)+'\n')
    temporary.replace(OUT/'report.json')


if __name__ == '__main__':
    main()
