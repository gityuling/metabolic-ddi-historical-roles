"""Refit the native graph pipeline after omitting one feature block at a time."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
MC = OUT.parent
sys.path.insert(0, str(MC/'history_ablation'))
from train import DATASETS, verified_split
import train_graph
from model import neighbors, latent, kernel

MODULES = {'neighbors': neighbors, 'latent': latent, 'kernel': kernel}


def run(dataset):
    source = MC/DATASETS[dataset]
    verified_split(source)
    expected = json.loads((MC/'history_ablation/audit.json').read_text())[dataset]['hashes']
    for file, digest in expected.items():
        assert hashlib.sha256((source/file).read_bytes()).hexdigest() == digest
    for omitted in MODULES:
        dest = OUT/dataset/('without_'+omitted)
        outputs = [dest/'run0'/f'graph{seed}{suffix}' for seed in range(5) for suffix in ('.json', '.cbm')]
        outputs.extend(dest/'run0'/f'graph_raw{seed}.npy' for seed in range(5))
        if all(f.is_file() for f in outputs) and (dest/'run0/cold.npy').is_file():
            continue
        kept = [mod for name, mod in MODULES.items() if name != omitted]
        print(dataset, 'without', omitted, flush=True)
        train_graph.main(source, [0], results_dir=dest, feature_modules=kept)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('dataset', choices=DATASETS)
    run(parser.parse_args().dataset)
