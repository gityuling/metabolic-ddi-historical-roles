from functools import lru_cache
from pathlib import Path
from collections import defaultdict
import hashlib
import json
import pandas as pd
import numpy as np
from rdkit import Chem, RDLogger
from rdkit.Chem.MolStandardize import rdMolStandardize
RDLogger.DisableLog('rdApp.warning')
DIR = Path(__file__).resolve().parent
ROOT = DIR.parents[3]
BASE = ROOT/'MFP-DDI'
IN = DIR/'inputs'

@lru_cache(None)
def identity(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None: raise ValueError('Invalid structure')
    parent = rdMolStandardize.ChargeParent(mol)
    return Chem.MolToSmiles(parent), Chem.MolToInchiKey(parent).split('-')[0]

@lru_cache(None)
def canonical(s):
    return Chem.MolToSmiles(Chem.MolFromSmiles(s))

def native():
    frames=[pd.read_csv(BASE/'data'/f'{s}_dataset.csv') for s in ('tr','val','tst')]
    drugs=sorted({s for f in frames for col in ('drug_A','drug_B') for s in f[col]})
    return frames,drugs

def reduced(frame):
    labels=defaultdict(set)
    for a,b,y in frame.itertuples(index=False,name=None):
        a,b=canonical(a),canonical(b)
        if a!=b: labels[tuple(sorted((a,b)))].add(y if a<b else (y+2)%4)
    return [(a,b,next(iter(ys))) for (a,b),ys in sorted(labels.items()) if len(ys)==1]

def structural_key(a,b):
    return tuple(sorted((identity(a)[1],identity(b)[1])))

def tied_choice(s):
    return hashlib.sha256(s.encode()).digest()

def metddi_iamv_probabilities(seed, original):
    """Use the longer-budget IAMV fits once all five seeds have been scored."""
    run = DIR/'iamv_extended'
    report = run/'report.json'
    if not report.is_file():
        return original
    summary = json.loads(report.read_text())
    assert summary['state'] == 'complete' and summary['dataset'] == 'MeTDDI'
    assert [row['seed'] for row in summary['runs']] == list(range(5))
    p = np.load(run/f'predictions{seed}.npy')
    assert p.shape == original.shape
    return p

def ci(d):
    d=np.asarray(d); rng=np.random.default_rng(20261119)
    draws=np.concatenate([rng.choice(d,(100,len(d))).mean(1) for _ in range(30)])
    return np.quantile(draws,[.025,.975])*100
