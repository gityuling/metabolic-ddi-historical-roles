"""Ablate the two historical annotation bits inside the published within-dataset fits."""
import argparse
from contextlib import ExitStack
from pathlib import Path
import sys
from unittest.mock import patch

import numpy as np
import pandas as pd
import torch

OUT = Path(__file__).resolve().parent
MC = OUT.parent
sys.path[:0] = [str(MC/'ddimdl_native_cv'), str(MC)]

DATASETS = {'EVENT_MEDIUM': 'event_medium_native', 'MecDDI': 'mecddi_native'}
ARMS = ('edges_only', 'effect_only', 'role_only')


def mask_channels(graph, arm):
    # Class index = 2 * affected endpoint + direction of metabolic change.
    n = graph.shape[-1]
    original = graph.reshape(2, 2, n, n)
    hidden = {'edges_only': (0, 1), 'effect_only': (0,), 'role_only': (1,)}[arm]
    masked = original.mean(dim=hidden, keepdim=True).expand_as(original)
    assert torch.equal(masked.sum((0, 1)), original.sum((0, 1)))
    for dim in hidden:
        assert torch.equal(masked.select(dim, 0), masked.select(dim, 1))
    if arm != 'edges_only':
        assert torch.equal(masked.sum(hidden), original.sum(hidden))
    return masked.reshape(4, n, n).contiguous()


def verified_split(source):
    data = pd.read_csv(source/'pairs.csv')
    parts = [key.split('|') for key in data.key]
    assert all(len(pair) == 2 and pair[0] < pair[1] for pair in parts) and data.key.is_unique
    with np.load(source/'fold0.npz') as split:
        batches = [split[key] for key in ('fit', 'val', 'test')]
    np.testing.assert_array_equal(np.sort(np.concatenate(batches)), np.arange(len(data)))
    for key, batch in zip(('fit', 'val', 'test'), batches):
        assert data.split.iloc[batch].eq(key).all()
    return data, batches


def train(name, arm):
    import train_graph
    import neighbors, latent, kernel
    from profiles import graph
    source = MC/DATASETS[name]
    verified_split(source)
    dest = OUT/name/arm
    if (dest/'run0'/'graph4.json').is_file():
        return
    def build_graph(n, edges):
        return mask_channels(graph(n, edges), arm)

    with ExitStack() as stack:
        for module in (neighbors, latent, kernel):
            stack.enter_context(patch.object(module, 'graph', build_graph))
        train_graph.main(source, [0], results_dir=dest)
    print(name, arm, 'complete', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('dataset', choices=DATASETS)
    parser.add_argument('arms', nargs='+', choices=ARMS)
    args = parser.parse_args()
    for arm in args.arms:
        train(args.dataset, arm)
