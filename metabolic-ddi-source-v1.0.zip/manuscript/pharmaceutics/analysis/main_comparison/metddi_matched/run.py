"""Matched validation of local refits on the MeTDDI unseen-pair benchmark."""
import sys
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch

OUT = Path(__file__).resolve().parent
MC = OUT.parent
sys.path.insert(0, str(MC))
from common import BASE, canonical, native, reduced
sys.path[:0] = [str(BASE), str(BASE/'novel_model'), str(BASE/'novel_model/.deps')]
from run import DDINetwork, load_split, probabilities
from boost import data_for, infer
from catboost import CatBoostClassifier

SWAP = [2, 3, 0, 1]


def split():
    frames, names = native()
    fit = reduced(frames[0])
    seen = {(a,b) for a,b,_ in fit}
    valid = [r for r in reduced(frames[1]) if r[:2] not in seen]
    raw_test = frames[2].iloc[np.load(BASE/'data/novel_test_indices.npy')]
    test = reduced(raw_test)
    cohorts = [pd.DataFrame(rows, columns=['a','b','y']) for rows in [fit, valid, test]]
    assert [len(f) for f in cohorts] == [155959,8655,6904]
    assert len(set((a,b) for a,b,_ in fit+valid+test)) == sum(map(len,cohorts))
    table = pd.concat([f.assign(split=s) for s,f in zip(['fit','val','test'],cohorts)])
    table.to_csv(OUT/'pairs.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    return frames, names, cohorts, raw_test


def indices(raw, cohort):
    sources = {}
    for i,(a,b,y) in enumerate(raw.itertuples(index=False,name=None)):
        a,b = canonical(a),canonical(b)
        key = tuple(sorted((a,b)))
        sources.setdefault(key,(i,a>b,y))
    entries = [sources[a,b] for a,b,y in cohort.itertuples(index=False,name=None)]
    ix, flip, y = map(np.array,zip(*entries))
    np.testing.assert_array_equal(np.where(flip,(y+2)%4,y),cohort.y)
    return ix,flip


def select_order(p, positions):
    ix, flip = positions
    return np.where(flip[:,None],p[ix][:,SWAP],p[ix])


def save_scores(name, seed, p, stage, validation):
    np.save(OUT/f'{name}{seed}.npy',p)
    (OUT/f'{name}{seed}.json').write_text(json.dumps(dict(stage=int(stage),validation=float(validation))))
    print(name,seed,'selected',stage,'validation',validation,flush=True)


def train_ours(frames, cohorts, raw_test):
    train,valid,_ = frames
    keys = set(zip(train.drug_A,train.drug_B))
    raw_val = valid.loc[[(a,b) not in keys and (b,a) not in keys for a,b in zip(valid.drug_A,valid.drug_B)]]
    vi,ti = indices(raw_val,cohorts[1]),indices(raw_test,cohorts[2])
    folds = [data_for(f'fold{i}',True,True) for i in range(8)]
    x = np.concatenate([f['x'] for f in folds])
    y = np.concatenate([f['y'] for f in folds])
    assert len(y)==2*len(cohorts[0])
    del folds
    val,test = [data_for(part,True,True) for part in ('valid','test')]
    for raw,f in [(raw_val,val),(raw_test,test)]:
        np.testing.assert_array_equal(raw.DDI,f['y'][:len(raw)])
    for seed in range(5):
        model = CatBoostClassifier(iterations=1400,depth=7,learning_rate=.09,random_seed=seed,
            task_type='GPU',devices='0',thread_count=5,verbose=False,allow_writing_files=False)
        model.fit(x,y)
        stages = list(range(100,1401,100))
        scores = [(select_order(infer(model,val,t),vi).argmax(1)==cohorts[1].y).mean() for t in stages]
        trees = stages[np.argmax(scores)]
        model.shrink(trees)
        model.save_model(str(OUT/f'ours{seed}.cbm'))
        save_scores('ours',seed,select_order(infer(model,test),ti),trees,max(scores))


def train_mfps(names,cohorts):
    fp,_,_ = load_split('cuda')
    lookup = {canonical(s):i for i,s in enumerate(names)}
    def tensor(f):
        return torch.tensor(np.column_stack([f.a.map(lookup),f.b.map(lookup),f.y]),device='cuda',dtype=torch.long)
    fit,val,test = map(tensor,cohorts)
    def aligned(model, rows):
        reverse = rows[:,[1,0,2]]
        return (probabilities(model,fp,rows)+probabilities(model,fp,reverse)[:,SWAP])/2
    torch.set_float32_matmul_precision('high')
    for seed in range(5):
        torch.manual_seed(seed)
        model=DDINetwork(2048,512,256,4,0.3).cuda()
        opt=torch.optim.Adam(model.parameters(),lr=1e-4,fused=True)
        best=-1
        for epoch in range(1,101):
            model.train()
            rows=fit[torch.randperm(len(fit),device='cuda')]
            flip=torch.rand(len(rows),device='cuda')<.5
            rows[flip,:2]=rows[flip,:2].flip(1)
            rows[flip,2]=(rows[flip,2]+2)%4
            for a,b,y in (batch.T for batch in rows.split(512)):
                opt.zero_grad(set_to_none=True)
                torch.nn.functional.cross_entropy(model(fp[a],fp[b]),y).backward()
                opt.step()
            score=(aligned(model,val).argmax(1)==val[:,2]).double().mean().item()
            if score>best:
                best,stage=score,epoch
                torch.save(model.state_dict(),OUT/f'mfps{seed}.pt')
        model.load_state_dict(torch.load(OUT/f'mfps{seed}.pt',weights_only=True))
        save_scores('mfps',seed,aligned(model,test).cpu().numpy(),stage,best)


if __name__=='__main__':
    frames,names,cohorts,raw_test=split()
    train_mfps(names,cohorts)
    train_ours(frames,cohorts,raw_test)
