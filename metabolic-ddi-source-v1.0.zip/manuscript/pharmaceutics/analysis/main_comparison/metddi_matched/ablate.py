"""Fit the four removals using the primary MeTDDI pair-level validation rule."""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from catboost import CatBoostClassifier

sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from main_comparison.metddi_matched.run import split, indices, select_order, BASE, OUT, data_for, infer

def features(part, arm):
    if arm=='without_roles':
        root=BASE/'novel_model/ablation'
        return dict(x=np.load(root/f'{part}_blind.npy'),y=np.load(root/f'{part}_rows.npy')[:,2])
    block=data_for(part,True,True)
    keep={'without_neighbors':slice(269,None),'without_kernel':slice(0,485),
          'without_latent':np.r_[0:269,485:565]}[arm]
    return dict(x=np.ascontiguousarray(block['x'][:,keep]),y=block['y'])

def main():
    frames,_,cohorts,raw_test=split()
    train,valid,_=frames
    seen=set(zip(train.drug_A,train.drug_B))
    raw_val=valid.loc[[(a,b) not in seen and (b,a) not in seen for a,b in zip(valid.drug_A,valid.drug_B)]]
    vi,ti=indices(raw_val,cohorts[1]),indices(raw_test,cohorts[2])
    for arm in ['without_roles','without_neighbors','without_latent','without_kernel']:
        folds=[features(f'fold{i}',arm) for i in range(8)]
        x=np.concatenate([f['x'] for f in folds])
        y=np.concatenate([f['y'] for f in folds])
        del folds
        val,test=features('valid',arm),features('test',arm)
        for records,block in [(raw_val,val),(raw_test,test)]:
            np.testing.assert_array_equal(records.DDI,block['y'][:len(records)])
        for seed in range(5):
            model=CatBoostClassifier(iterations=1400,depth=7,learning_rate=.09,random_seed=seed,
                task_type='GPU',devices='0',thread_count=5,verbose=False,allow_writing_files=False)
            model.fit(x,y)
            scores=[]
            for prob in model.staged_predict_proba(val['x'],eval_period=100,thread_count=5):
                forward,reverse=np.split(prob,2)
                p=select_order((forward+reverse[:,[2,3,0,1]])/2,vi)
                scores.append((p.argmax(1)==cohorts[1].y).mean())
            trees=(1+np.argmax(scores))*100
            p=select_order(infer(model,test,int(trees)),ti)
            np.save(OUT/f'{arm}{seed}.npy',p)
            np.save(OUT/f'{arm}{seed}_validation.npy',scores)
            print(arm,seed,trees,flush=True)

if __name__=='__main__': main()
