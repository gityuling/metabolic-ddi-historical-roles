"""Run the established within-source model recipes on EVENT_MEDIUM Task 1."""
from pathlib import Path
import sys

OUT=Path(__file__).resolve().parent
sys.path[:0]=[str(OUT.parent/'ddimdl_native_cv'),str(OUT.parent)]

if __name__=='__main__':
    method=sys.argv[1]
    if len(sys.argv)>2:
        OUT=Path(sys.argv[2]).resolve()
    if method=='tokens':
        import numpy as np
        import pandas as pd
        import torch
        from tokens import encode_names
        torch.manual_seed(0)
        np.random.seed(0)
        data=pd.read_csv(OUT/'pairs.csv')
        names=set(data.a)|set(data.b)
        cache=torch.load(OUT.parent/'tokens.pt',weights_only=True) if (OUT.parent/'tokens.pt').exists() else {}
        initial={s:t for s,t in cache.items() if s in names}
        print('known',len(initial),'of',len(names),flush=True)
        encode_names(names, OUT/'tokens.pt', initial, restrict=True)
    elif method=='graph':
        from train_graph import main
        main(OUT,[0])
    elif method in ('mfps','iamv'):
        from train_neural import train
        train(method,OUT,[0],OUT/'tokens.pt')
    else:
        raise ValueError(method)
