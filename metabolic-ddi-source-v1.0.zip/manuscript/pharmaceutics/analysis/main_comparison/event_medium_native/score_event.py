"""Score five predictions per held-out pair and pair-bootstrap the seed-mean differences."""
from pathlib import Path
import sys

import numpy as np
import pandas as pd

OUT=Path(__file__).resolve().parent
sys.path[:0]=[str(OUT.parent/'ddimdl_native_cv'),str(OUT.parent)]
from score import evaluate
from common import ci


def main(out=OUT,expected_total=23017,expected_test=4572):
    runs=out/'run0'
    d=pd.read_csv(out/'pairs.csv')
    with np.load(out/'fold0.npz') as sp:
        for key in ('fit','val','test'):
            assert (d.split.iloc[sp[key]]==key).all()
        assert len(np.unique(np.r_[sp['fit'],sp['val'],sp['test']]))==len(d)==expected_total
        fit=d.iloc[sp['fit']]
        test=d.iloc[sp['test']].reset_index(drop=True)
    assert d.key.is_unique and len(test)==expected_test
    assert d.a.groupby(d.key.str.split('|',regex=False).str[0]).nunique().max()==1
    history=set(fit.a)|set(fit.b)
    cold=~(test.a.isin(history)&test.b.isin(history)).to_numpy()
    np.testing.assert_array_equal(cold,np.load(runs/'cold.npy'))
    scores=[]
    correct={}
    for seed in range(5):
        mfps=np.load(runs/f'mfps{seed}.npy')
        graph=np.load(runs/f'graph_raw{seed}.npy')
        ours=np.where(cold[:,None],mfps,graph)
        np.save(runs/f'ours{seed}.npy',ours)
        for name,p in [('Ours',ours),('MFPs',mfps),('IAMV-DDI',np.load(runs/f'iamv{seed}.npy'))]:
            assert p.shape==(expected_test,4)
            metrics,hits,roles=evaluate(test,p)
            y=test.y.to_numpy()
            forward=p.argmax(axis=1)
            swapped=(p[:,[2,3,0,1]].argmax(axis=1)+2)%4
            expected=50*((forward==y).mean()+(swapped==y).mean())
            np.testing.assert_allclose(metrics['accuracy'],expected,atol=1e-8)
            if (forward!=swapped).any():
                tied=(p==p.max(axis=1,keepdims=True)).sum(axis=1)>1
                assert tied[forward!=swapped].all()
            scores.append(dict(method=name,seed=seed,**metrics))
            correct.setdefault(name,[]).append([hits,roles])
    per=pd.DataFrame(scores)
    per.to_csv(out/'seed_scores.csv',index=False)
    grouped=per.drop(columns='seed').groupby('method',sort=False)
    summary=grouped.mean().join(grouped.std(ddof=0).add_suffix('_seed_sd'))
    summary.to_csv(out/'summary.csv')
    contrasts=[]
    for reference in ['MFPs','IAMV-DDI']:
        for metric,diff in zip(['accuracy','role_accuracy'],np.mean(correct['Ours'],axis=0)-np.mean(correct[reference],axis=0)):
            lo,hi=ci(diff)
            contrasts.append(dict(baseline=reference,metric=metric,delta_pp=100*diff.mean(),low=lo,high=hi))
    pd.DataFrame(contrasts).to_csv(out/'contrasts.csv',index=False)
    print(summary[['accuracy','role_accuracy','macro_f1','macro_aupr']].round(3))
    print('Test pairs with a drug unseen during fitting:',cold.sum())

if __name__=='__main__':
    main()
