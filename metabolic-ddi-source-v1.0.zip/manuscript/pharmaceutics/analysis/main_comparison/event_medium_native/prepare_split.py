"""Rebuild the pair-disjoint Task 1 metabolic benchmark from the pinned SQLite release."""
from collections import defaultdict
from pathlib import Path
import hashlib
import json
import sqlite3
import sys

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedShuffleSplit

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parent))
from common import canonical, identity

def main():
    db = OUT / 'event_medium.db'
    assert hashlib.md5(db.read_bytes()).hexdigest() == 'e4bee68c5ed03dfab18487ab8b4bb661'
    groups = defaultdict(list)
    structures = defaultdict(set)
    effects = {'The metabolism of drugA can be ' + effect + ' when combined with drugB': i
               for i, effect in enumerate(['decreased', 'increased'])}
    with sqlite3.connect(db.resolve().as_uri()+'?mode=ro', uri=True) as conn:
        drugs = dict(conn.execute('select drug_id,original_smiles from drug'))
        rows = conn.execute('select drug_id1,drug_id2,interaction,train_task1,test_task1 from event_tasks where lower(interaction) like "the metabolism of%"')
        for a,b,mechanism,tr,te in rows:
            assert tr+te == 1
            effect = effects[mechanism]
            try:
                sa,sb = canonical(drugs[a]),canonical(drugs[b])
                ka,kb = identity(drugs[a])[1],identity(drugs[b])[1]
            except (ValueError,TypeError,KeyError):
                continue
            if not ka or not kb or ka == kb:
                continue
            structures[ka].add(sa)
            structures[kb].add(sb)
            lo,hi = sorted([ka,kb])
            groups[lo,hi].append((2*int(ka>kb)+effect, int(te)))
    pairs = []
    mixed = conflicts = 0
    for (lo,hi), records in sorted(groups.items()):
        if len({y for y,_ in records}) != 1:
            conflicts += 1
            continue
        if len({side for _,side in records}) != 1:
            mixed += 1
            continue
        y,side = records[0]
        pairs.append(dict(key=lo+'|'+hi, a=min(structures[lo]), b=min(structures[hi]), y=y,role=y//2,
                          split='test' if side else 'fit'))
    d = pd.DataFrame(pairs)
    pool = np.flatnonzero(d.split=='fit')
    test = np.flatnonzero(d.split=='test')
    assert (len(pool),len(test),mixed,conflicts)==(18445,4572,254,166) and d.key.is_unique
    fi,vi = next(StratifiedShuffleSplit(1,test_size=.1,random_state=171).split(pool,d.y.iloc[pool]))
    fit,val = pool[fi],pool[vi]
    d.loc[val,'split'] = 'val'
    assert len(set(np.r_[fit,val,test])) == len(d)
    d.to_csv(OUT/'pairs.csv',index=False)
    np.savez(OUT/'fold0.npz',fit=fit,val=val,test=test)
    audit=dict(fit=len(fit),validation=len(val),test=len(test),discarded_mixed=mixed,
               discarded_label_conflicts=conflicts,structures=len(set(d.a)|set(d.b)),
               counts_by_split_and_y=d.groupby(['split','y']).size().unstack().to_dict('index'))
    (OUT/'audit.json').write_text(json.dumps(audit,indent=2))
    print(audit)

if __name__=='__main__':
    main()
