"""Four-way adaptation of the published IAMV-DDI multiclass head and frozen encoders."""
from common import *
import torch, sys, time, json
from torch.nn import functional as F
sys.path.insert(0,str(ROOT/'IAMV-DDI'))
from src.model.model_ddi import DDIHead
from torch.nn.utils.rnn import pad_sequence
torch.set_num_threads(2)
torch.backends.mha.set_fastpath_enabled(False)

def representation(i,x2,x3,mask2,mask3):
    a,b=i.proj2(x2),i.proj3(x3)
    ap=i.xattn_2_to_3[0](a,b,key_padding_mask=mask3)
    bp=i.xattn_3_to_2[0](b,a,key_padding_mask=mask2)
    u=i.pool2(ap,mask2); v=i.pool3(bp,mask3)
    return i.ln(i.fuse_proj(torch.cat([u,v],-1)))

def logits(m,a,b):
    a,b=m.inter(a,b)
    a=m.ln(m.drop(m.pool_h(a))); b=m.ln(m.drop(m.pool_t(b)))
    return m.fc_layers(torch.cat([a,b,(a-b).abs(),a*b],-1))

class Drugs:
    def __init__(self,native_only=False,token_path=None):
        t=torch.load(token_path or DIR/'tokens.pt',weights_only=True)
        self.names=sorted(set(map(canonical,native()[1])) if native_only else t); self.index={s:i for i,s in enumerate(self.names)}
        self.tokens=[t[s][:2] for s in self.names]
        self.pad=[pad_sequence([p[k] for p in self.tokens],batch_first=True).cuda() for k in (0,1)]
        self.length=[np.array([len(p[k]) for p in self.tokens]) for k in (0,1)]
    def encode(self,m,indices):
        lengths=np.maximum(self.length[0][indices],self.length[1][indices])
        if lengths.max()>128 and len(indices)>1:
            # Long molecules should not force every short molecule to pad to their length.
            buckets=(lengths-1)//64
            order=np.argsort(buckets,kind='stable')
            groups=np.split(order,1+np.flatnonzero(np.diff(buckets[order])))
            parts=[self._encode_padded(m,indices[group]) for group in groups]
            return torch.cat(parts)[np.argsort(order)]
        return self._encode_padded(m,indices)
    def _encode_padded(self,m,indices):
        arr=[]; masks=[]
        for x,l in zip(self.pad,self.length):
            lens=l[indices]; mx=int(lens.max())
            arr.append(x[indices,:mx]); masks.append(torch.arange(mx,device='cuda')[None,:]>=torch.as_tensor(lens,device='cuda')[:,None])
        return representation(m.intra,*arr,*masks)
    def rows(self,rows):
        return np.array([(self.index[a],self.index[b],y) for a,b,y in rows],dtype=np.int64)
    @torch.no_grad()
    def predict(self,m,q):
        m.eval()
        with torch.autocast('cuda',torch.bfloat16):
            emb=torch.cat([self.encode(m,ids) for ids in np.array_split(np.arange(len(self.names)),max(1,len(self.names)//48))])
            out=[]
            for batch in np.array_split(q,max(1,len(q)//384)):
                a,b=emb[batch[:,0]],emb[batch[:,1]]
                p=logits(m,a,b).float().softmax(1); r=logits(m,b,a).float().softmax(1)
                out.append(((p+r[:,[2,3,0,1]])/2).cpu().numpy())
        return np.vstack(out)

def main():
    d=Drugs(native_only=True); fs,_=native()
    tr=reduced(fs[0]); used={(a,b) for a,b,y in tr}
    val=[r for r in reduced(fs[1]) if r[:2] not in used]
    q,v=d.rows(tr),d.rows(val)
    train_heads(d,q,v,DIR/'formal')

def train_heads(d,q,v,folder,*,max_epochs=70,min_epochs=0,patience=None):
    print('training and validation',len(q),len(v),flush=True)
    folder.mkdir(parents=True,exist_ok=True)
    for seed in range(5):
        if (folder/f'iamv_history{seed}.json').exists(): continue
        torch.manual_seed(seed); rng=np.random.default_rng(seed)
        m=DDIHead(num_rel=4).cuda()
        m.eval()
        with torch.no_grad():
            ab=np.array([0,1]); ref=m(*[[d.tokens[i][k].cuda() for i in ids] for ids in (ab,ab[::-1]) for k in (0,1)])[0]
            em=d.encode(m,ab); torch.testing.assert_close(logits(m,em,em.flip(0)),ref,atol=3e-5,rtol=3e-4)
        opt=torch.optim.AdamW(m.parameters(),lr=5e-4,weight_decay=5e-4,fused=True)
        best=-1; best_epoch=0; hist=[]; start=time.monotonic()
        for epoch in range(max_epochs):
            rows=q.copy()
            flip=rng.integers(2,size=len(q)).astype(bool)
            rows[flip,:2]=rows[flip,:2][:,::-1]; rows[flip,2]=(rows[flip,2]+2)%4
            # Two independent random drug partitions yield manageable batches with repeated structures.
            groups=rng.permutation(len(d.names))//80
            key=groups[rows[:,0]]*(groups.max()+1)+groups[rows[:,1]]
            order=np.argsort(key,kind='stable'); chunks=np.split(order,1+np.flatnonzero(np.diff(key[order])))
            rng.shuffle(chunks); batches=[b for c in chunks for b in np.array_split(c,(len(c)+639)//640)]
            m.train()
            for j,ix in enumerate(batches,1):
                z=rows[ix]; ids,idx=np.unique(z[:,:2],return_inverse=True); idx=idx.reshape(-1,2)
                opt.zero_grad(set_to_none=True)
                with torch.autocast('cuda',torch.bfloat16):
                    t=d.encode(m,ids); out=logits(m,t[idx[:,0]],t[idx[:,1]])
                    loss=F.cross_entropy(out,torch.as_tensor(z[:,2],device='cuda'))
                loss.backward(); torch.nn.utils.clip_grad_norm_(m.parameters(),1.); opt.step()
                if j==len(batches) and (epoch+1)%5==0:
                    p=d.predict(m,v); acc=float((p.argmax(1)==v[:,2]).mean())
                    hist.append({'epoch':epoch+j/len(batches),'val_accuracy':acc,'seconds':round(time.monotonic()-start,1)})
                    if acc>best:
                        best=acc; best_epoch=epoch+1
                        torch.save(m.state_dict(),folder/f'iamv{seed}.pt')
                    print(seed,hist[-1],flush=True); m.train()
            if (patience is not None and (epoch+1)%5==0 and epoch+1>=min_epochs
                    and epoch+1-best_epoch>=5*patience):
                break
        history=folder/f'iamv_history{seed}.json'
        temporary=history.with_suffix('.tmp')
        temporary.write_text(json.dumps(hist,indent=2)+'\n')
        temporary.replace(history)
if __name__=='__main__': main()
