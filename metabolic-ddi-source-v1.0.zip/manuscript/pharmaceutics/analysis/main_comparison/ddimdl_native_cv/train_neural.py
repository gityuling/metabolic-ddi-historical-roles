"""Fit either structural model on the same DDIMDL fitting labels from scratch."""
import json, sys
from folds import OUT
from common import BASE
from iamv import Drugs, DDIHead, logits
sys.path.insert(0,str(BASE))
from run import DDINetwork
from rdkit import Chem
from rdkit.Chem import AllChem
import torch
import torch.nn.functional as F
import numpy as np
import pandas as pd

def train(method,out=OUT,folds=range(5),token_path=None):
    torch.set_num_threads(2)
    d=pd.read_csv(out/'pairs.csv')
    drugs=Drugs(token_path=token_path) if method=='iamv' else None
    names=drugs.names if drugs else sorted(set(d.a)|set(d.b))
    ids={s:i for i,s in enumerate(names)}
    q=np.column_stack([d.a.map(ids),d.b.map(ids),d.y]).astype(np.int64)
    fp=None if drugs else torch.tensor(np.stack([np.asarray(AllChem.GetMorganFingerprintAsBitVect(Chem.MolFromSmiles(s),2,nBits=2048)) for s in names]),device='cuda',dtype=torch.float32)
    for fold in folds:
        split=np.load(out/f'fold{fold}.npz');fit,val,test=[q[split[s]] for s in ('fit','val','test')]
        folder=out/f'run{fold}';folder.mkdir(exist_ok=True)
        for seed in range(5):
            prefix=f'{method}{seed}'; done=folder/f'{prefix}.json'
            if done.exists():continue
            torch.manual_seed(seed);rng=np.random.default_rng(seed)
            m=(DDIHead(num_rel=4) if drugs else DDINetwork(2048,512,256,4,.3)).cuda()
            opt=torch.optim.AdamW(m.parameters(),lr=.0005,weight_decay=.0005)
            @torch.no_grad()
            def predict(rows):
                m.eval()
                if drugs:return drugs.predict(m,rows)
                res=[]
                for b in np.array_split(rows,max(1,(len(rows)+511)//512)):
                    a,z=fp[b[:,0]],fp[b[:,1]]
                    res.append(((m(a,z).softmax(1)+m(z,a).softmax(1)[:,[2,3,0,1]])/2).cpu().numpy())
                return np.vstack(res)
            best=np.inf;trace=[]
            for epoch in range(1,61):
                batch=fit[rng.permutation(len(fit))].copy()
                flip=rng.random(len(batch))<.5;batch[flip,:2]=batch[flip,:2][:,::-1];batch[flip,2]=(batch[flip,2]+2)%4
                m.train()
                for b in np.array_split(batch,(len(batch)+511)//512):
                    opt.zero_grad(set_to_none=True)
                    if drugs:
                        indices,ix=np.unique(b[:,:2],return_inverse=True);ix=ix.reshape(-1,2)
                        with torch.autocast('cuda',torch.bfloat16):
                            em=drugs.encode(m,indices);pred=logits(m,em[ix[:,0]],em[ix[:,1]]).float()
                    else:pred=m(fp[b[:,0]],fp[b[:,1]])
                    F.cross_entropy(pred,torch.as_tensor(b[:,2],device='cuda')).backward()
                    torch.nn.utils.clip_grad_norm_(m.parameters(),1);opt.step()
                if epoch%10==0:
                    p=predict(val);loss=float(-np.log(p[np.arange(len(p)),val[:,2]].clip(1e-12)).mean());trace.append(loss)
                    if loss<best:
                        best=loss;chosen=epoch;torch.save(m.state_dict(),folder/f'{prefix}.pt')
            m.load_state_dict(torch.load(folder/f'{prefix}.pt',weights_only=True))
            np.save(folder/f'{prefix}.npy',predict(test))
            done.write_text(json.dumps(dict(epoch=chosen,validation_losses=trace)))
            print(method,fold,seed,'done',flush=True)
if __name__=='__main__':train(sys.argv[1])
