"""Cross-fit training history and select graph heads using only the inner validation set."""
import sys
import json
import numpy as np
import pandas as pd
from folds import OUT
sys.path.insert(0,str(OUT.parent/'ddimdl_adaptation'))
from model import make_features, CatBoostClassifier, SWAP

def main(out=OUT,folds=range(5),*,results_dir=None,feature_modules=None):
    d=pd.read_csv(out/'pairs.csv')
    for k in folds:
        dest=(results_dir or out)/f'run{k}';dest.mkdir(parents=True,exist_ok=True)
        split=np.load(out/f'fold{k}.npz');fit,val,test=[split[s] for s in ('fit','val','test')]
        hist={drug for key in d.key.iloc[fit] for drug in key.split('|')}
        cold=np.array([any(drug not in hist for drug in key.split('|')) for key in d.key.iloc[test]])
        np.save(dest/'cold.npy',cold)
        # Held-out rows occupy the tail, in validation then evaluation order.
        g=d.iloc[np.r_[fit,val,test]].reset_index(drop=True)
        g['split']=np.repeat(['history','calibration','evaluation'],[len(fit),len(val),len(test)])
        x,y,ext,ids=make_features(g) if feature_modules is None else make_features(g,feature_modules)
        assert np.array_equal(ids,np.arange(len(fit),len(g)))
        for seed in range(5):
            m=CatBoostClassifier(iterations=600,depth=5,learning_rate=.07,random_seed=seed,thread_count=5,verbose=False,allow_writing_files=False)
            m.fit(x,y)
            msize=len(val)+len(test);vix=np.r_[np.arange(len(val)),msize+np.arange(len(val))]
            losses=[]
            for ntree in range(100,601,100):
                f,r=np.split(m.predict_proba(ext[vix],ntree_end=ntree),2);p=(f+r[:,SWAP])/2
                losses.append(float(-np.log(p[np.arange(len(val)),d.y.iloc[val].to_numpy()].clip(1e-12)).mean()))
            chosen=100*(1+np.argmin(losses));m.shrink(int(chosen));m.save_model(str(dest/f'graph{seed}.cbm'))
            f,r=np.split(m.predict_proba(ext),2)
            np.save(dest/f'graph_raw{seed}.npy',((f+r[:,SWAP])/2)[len(val):])
            (dest/f'graph{seed}.json').write_text(json.dumps(dict(trees=int(chosen),validation_losses=losses)))
            print(k,seed,'done',flush=True)
if __name__=='__main__':main()
