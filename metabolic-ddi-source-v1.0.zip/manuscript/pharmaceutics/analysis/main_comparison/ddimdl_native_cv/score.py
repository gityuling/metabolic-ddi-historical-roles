"""Pool one held-out prediction per pair for each independently trained seed."""
import json
import numpy as np
import pandas as pd
from sklearn.metrics import (balanced_accuracy_score,precision_recall_fscore_support,
                             roc_auc_score, confusion_matrix)
from folds import OUT
from common import ci,tied_choice
from summarize import metrics
SWAP=[2,3,0,1]
MODELS=['Ours','MFPs','IAMV-DDI']

def evaluate(d,p):
    m,correct=metrics(d,p)
    y=d.y.to_numpy();both=np.r_[y,(y+2)%4]
    two=np.vstack([p,p[:,SWAP]])
    pred=two.argmax(1)
    inc=p[:,1]+p[:,3]>.5
    first,second=p[:,:2].sum(1),p[:,2:].sum(1)
    who=np.where(first==second,[int(tied_choice(a)>tied_choice(b)) for a,b in zip(d.a,d.b)],second>first)
    role_hit=(who==y//2).astype(float)
    assert np.isclose(m['role_accuracy'],role_hit.mean())
    m.update(balanced_accuracy=balanced_accuracy_score(both,pred),
             effect_accuracy=(inc==y%2).mean(),increase_recall=inc[y%2==1].mean(),
             increase_precision=(y[inc]%2).mean() if inc.any() else 0.,
             role_auroc=roc_auc_score(both//2,two[:,2:].sum(1)))
    return {name:value*100 for name,value in m.items()}, correct,role_hit

def main():
    d=pd.read_csv(OUT/'pairs.csv');seeds=range(5)
    all_p={m:np.full((5,len(d),4),np.nan) for m in MODELS}
    seen=np.zeros(len(d),dtype=int);stats=[];fold_results=[];class_rows=[];matrices=[]
    for k in range(5):
        sp=np.load(OUT/f'fold{k}.npz');fit,val,test=(sp[s] for s in ['fit','val','test'])
        assert np.array_equal(test,np.where(d.fold==k)[0]);seen[test]+=1
        assert len(np.unique(np.r_[fit,val,test]))==len(d)==len(fit)+len(val)+len(test)
        h=set(v for key in d.key.iloc[fit] for v in key.split('|'))
        cold=np.array([any(v not in h for v in key.split('|')) for key in d.key.iloc[test]])
        folder=OUT/f'run{k}'
        np.testing.assert_array_equal(cold,np.load(folder/'cold.npy'))
        stats.append(dict(fold=k,fit=len(fit),validation=len(val),test=len(test),increase=int((d.y.iloc[test]%2).sum()),cold=int(cold.sum())))
        for s in seeds:
            mf=np.load(folder/f'mfps{s}.npy')
            raw=np.load(folder/f'graph_raw{s}.npy')
            for method,p in zip(MODELS,[np.where(cold[:,None],mf,raw),mf,np.load(folder/f'iamv{s}.npy')]):
                values,_,_=evaluate(d.iloc[test],p);all_p[method][s,test]=p
                fold_results.append(dict(method=method,fold=k,seed=s,**values))
    assert (seen==1).all()
    pd.DataFrame(stats).to_csv(OUT/'fold_sizes.csv',index=False)
    fold_frame=pd.DataFrame(fold_results)
    fold_frame.to_csv(OUT/'fold_scores.csv',index=False)
    mean_by_fold=fold_frame.drop(columns='seed').groupby(['method','fold']).mean()
    fold_summary=mean_by_fold.groupby('method').agg(['mean','std'])
    fold_summary.columns=['_fold_'.join(c) for c in fold_summary.columns]
    fold_summary.to_csv(OUT/'fold_summary.csv')
    comparisons={};seed_results=[]
    for method,ps in all_p.items():
        np.save(OUT/f'oof_{method}.npy',ps)
        hits=[]
        for s,p in enumerate(ps):
            values,acc,role=evaluate(d,p);hits.append(np.stack([acc,role]))
            seed_results.append(dict(method=method,seed=s,**values))
            y=d.y.to_numpy();y=np.r_[y,(y+2)%4]
            hat=np.vstack([p,p[:,SWAP]]).argmax(1)
            pr,rec,f1,support=precision_recall_fscore_support(y,hat,labels=list(range(4)),zero_division=0)
            for c in range(4):
                class_rows.append(dict(method=method,seed=s,label=c,support_oriented=int(support[c]),precision=100*pr[c],recall=100*rec[c],f1=100*f1[c]))
            mat=confusion_matrix(y,hat,labels=list(range(4)))
            for i,j in np.ndindex(mat.shape):
                matrices.append(dict(method=method,seed=s,truth=i,pred=j,count=int(mat[i,j])))
        comparisons[method]=np.mean(hits,axis=0)
    per=pd.DataFrame(seed_results);per.to_csv(OUT/'seed_scores.csv',index=False)
    summary=per.drop(columns='seed').groupby('method',sort=False).mean()
    summary['accuracy_seed_sd']=per.groupby('method').accuracy.std(ddof=0)
    summary['role_seed_sd']=per.groupby('method').role_accuracy.std(ddof=0)
    summary.to_csv(OUT/'summary.csv')
    pd.DataFrame(class_rows).to_csv(OUT/'per_class.csv',index=False)
    pd.DataFrame(matrices).to_csv(OUT/'confusion_counts.csv',index=False)
    bounds=[]
    for m in MODELS[1:]:
        for j,label in enumerate(['accuracy','role_accuracy']):
            diff=comparisons['Ours'][j]-comparisons[m][j]
            lo,hi=ci(diff);bounds.append(dict(baseline=m,metric=label,delta_pp=100*diff.mean(),low=lo,high=hi))
    pd.DataFrame(bounds).to_csv(OUT/'contrasts.csv',index=False)
    print(summary.round(3).to_string())
if __name__=='__main__':main()
