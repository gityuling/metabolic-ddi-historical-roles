"""Encode structures with the frozen IAMV-DDI TokenMAE and EGNN checkpoints."""
from common import *
import sys, torch
from torch_geometric.data import Data
from torch_geometric.data.data import DataEdgeAttr, DataTensorAttr
from torch_geometric.data.storage import GlobalStorage
sys.path.insert(0,str(ROOT/'IAMV-DDI'))
from src.model.pretrain_loader import instantiate_tokenmae_2d, load_tokenmae_checkpoint, extract_state_dict, EGNN, load_drug2d_cache_from_data_pt
from src.model.encoder import encode_2d_encoder128, encode_3d_encoder128
from src.pretrained_3D.utils import build_bond_graph_rdkit
from src.pretrained_3D.conformers import inner_smi2coords

def graphs(s):
    mol=Chem.MolFromSmiles(s)
    atoms=list(mol.GetAtoms())
    x=torch.tensor([[a.GetAtomicNum()-1,int(a.GetChiralTag()) if int(a.GetChiralTag())<4 else 3] for a in atoms])
    edges,attr,n=build_bond_graph_rdkit(s,'cpu')
    bonds=[(int(v[1:5].argmax()), {0:0,4:1,3:2}.get(int(b.GetBondDir()),0)) for v,b in zip(attr[::2],mol.GetBonds())]
    g=Data(x=x,edge_index=edges,edge_attr=torch.tensor(bonds,dtype=torch.long).reshape(-1,2).repeat_interleave(2,0))
    symbols,xyz=inner_smi2coords(s,remove_hs=False)
    assert symbols[:n]==[a.GetSymbol() for a in atoms]
    xyz=xyz[:n]
    h=torch.nn.functional.one_hot(x[:,0].clamp(0,63),64).float()
    assert n==len(x)==len(xyz)
    return g,(h,torch.from_numpy(xyz),edges,attr)

def main():
    _,raw=native()
    names=set(map(canonical,raw))
    if (DIR/'external.csv').exists():
        df=pd.read_csv(DIR/'external.csv'); names.update(df.a); names.update(df.b)
    encode_names(names,DIR/'tokens.pt')

def encode_names(names,target,initial=None,restrict=False):
    cache=torch.load(target,weights_only=True) if target.exists() else dict(initial or {})
    tokens={s:cache[s] for s in names if s in cache} if restrict else cache
    if set(names)<=tokens.keys():
        if not target.exists() or len(cache)!=len(tokens):
            torch.save(tokens,target.with_suffix('.tmp'))
            target.with_suffix('.tmp').replace(target)
        return
    m2=load_tokenmae_checkpoint(instantiate_tokenmae_2d(),IN/'2d.pth').eval()
    m3=EGNN(in_node_nf=64,hidden_nf=128,out_node_nf=128,in_edge_nf=13,device='cuda',n_layers=4).cuda().eval()
    m3.load_state_dict(extract_state_dict(torch.load(IN/'3d.pt',map_location='cpu',weights_only=True)))
    with torch.serialization.safe_globals([Data,DataTensorAttr,DataEdgeAttr,GlobalStorage]):
        g2=load_drug2d_cache_from_data_pt(IN/'2d_cache.pt',IN/'id_map.csv')
    g3=torch.load(IN/'3d_cache.pt',map_location='cpu',weights_only=True)
    ids={}
    for row in pd.read_csv(IN/'id_map.csv').itertuples():
        if row.idx in g2 and row.idx in g3 and g3[row.idx][1] is not None:
            try: ids[canonical(row.smiles)]=row.idx
            except (ValueError,TypeError): pass
    with torch.no_grad():
        for i,s in enumerate(sorted(names-tokens.keys())):
            if s in ids:
                k=ids[s]; g,t=g2[k],g3[k]; source='author'
            else:
                g,t=graphs(s); source='generated'
            h2=encode_2d_encoder128(m2,g.to('cuda')).detach().cpu()
            h3=encode_3d_encoder128(m3,*[v.cuda() for v in t]).detach().cpu()
            assert h2.isfinite().all() and h3.isfinite().all()
            tokens[s]=(h2,h3,source)
            if i%100==0: print('encoded',i,len(names),flush=True)
    torch.save(tokens,target.with_suffix('.tmp')); target.with_suffix('.tmp').replace(target)
if __name__=='__main__': main()
