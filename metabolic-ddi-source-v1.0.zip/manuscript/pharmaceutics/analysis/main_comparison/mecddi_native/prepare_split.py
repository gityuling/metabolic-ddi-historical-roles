"""Build four labels from released MecDDI enzyme roles and the published PKAG random split 0."""
from collections import Counter, defaultdict
from functools import lru_cache
from pathlib import Path
import hashlib
import json
import pickle
import sys

import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent
RAW = OUT/'raw'
sys.path.insert(0,str(OUT.parent))
from common import identity, canonical

class DataOnly(pickle.Unpickler):
    def find_class(self,module,name):
        raise ValueError(f'Unexpected global in data: {module}.{name}')

PREFIX='Affected intra/extra-hepatic metabolism'
EFFECTS={f'{PREFIX} ({family} {action})':i for family,actions in [
    ('CYP450 enzyme',('inhibition','induction')),('UGT',('inhibition','induction')),
    ('Non-CYP450 enzyme',('inhibition',))] for i,action in enumerate(actions)}

def mechanism_label(description,first,second):
    effect=EFFECTS.get(description)
    if effect is None:
        return None
    roles=[str(role).strip().casefold() for role in (first,second)]
    mod=' inducer' if effect else ' inhibitor'
    for j in (0,1):
        if roles[j].endswith(' substrate') and roles[1-j]==roles[j][:-10]+mod:
            return j,effect
    return None

def norm(name):
    return ' '.join(name.casefold().split())

@lru_cache(None)
def molecule(s):
    if not s or s in ('NA','-','.'):return None
    try:
        key=identity(s)[1]
        if key:return key,canonical(s)
    except (TypeError,ValueError,RuntimeError):
        pass
    return None

def main():
    with (RAW/'compact.pkl').open('rb') as f:
        records=DataOnly(f).load()
    source=RAW/'all_ddi_addSMIELS_raw.pkl'
    assert hashlib.sha256(source.read_bytes()).hexdigest()=='923d93a31154c70ebce30cd59cfbdbd024719757539f0deef090d41656104b9d'
    with source.open('rb') as f:
        original=DataOnly(f).load()
    assignments={}
    for name,file in [('fit','train'),('val','val'),('test','test')]:
        ids=(RAW/f'{file}_seed0.txt').read_text().splitlines()
        assert not set(ids).intersection(assignments) and len(ids)==len(set(ids))
        assignments.update(dict.fromkeys(ids,name))
    assert set(assignments)<=set(records)
    info=pd.read_csv(RAW/'drugs.csv',encoding='latin1',keep_default_na=False)
    by_id={r.Drug_ID:norm(r.Drug_Name) for r in info.itertuples()}
    forms=defaultdict(set)
    for r in info.itertuples():
        mol=molecule(r.Canonical_SMILES)
        if mol: forms[norm(r.Drug_Name)].add(mol)
    names={n:min(v) for n,v in forms.items() if len({k for k,_ in v})==1}
    raw=pd.read_csv(RAW/'metabolism.csv',encoding='latin1')
    official={tuple(sorted((by_id[r.A_Drug_ID],by_id[r.B_Drug_ID]))) for r in raw.itertuples()}
    status=Counter(); groups=defaultdict(list); splits=defaultdict(set); smiles=defaultdict(set)
    for rid,r in records.items():
        if rid not in assignments:continue
        n1,n2=map(norm,(r['drug1_name'],r['drug2_name']))
        metabolic=r['mechanism_des'].startswith(PREFIX)
        if n1 not in names or n2 not in names:
            if metabolic:status['missing_structure_or_name']+=1
            continue
        (k1,s1),(k2,s2)=names[n1],names[n2]
        if k1==k2:
            if metabolic:status['self_pair']+=1
            continue
        key='|'.join(sorted((k1,k2)))
        splits[key].add(assignments[rid])
        if not metabolic:continue
        if tuple(sorted((n1,n2))) not in official:
            status['absent_from_official_metabolic_table']+=1
            continue
        smiles[k1].add(s1);smiles[k2].add(s2)
        full=original[rid]
        assert (full['drug1_name'],full['drug2_name'],full['mechanism_des'])==(r['drug1_name'],r['drug2_name'],r['mechanism_des'])
        mapping=mechanism_label(r['mechanism_des'],r['function1'],r['function2'])
        if mapping is not None:
            supported={mechanism_label(full['mechanism_des'],part.get('drug1'),part.get('drug2'))
                       for k,part in full.items() if k.startswith('Mechanism_')}
            if supported!={mapping}:
                mapping=None
        y=None
        if mapping is not None:
            victim,effect=mapping
            y=2*(victim^int(k1>k2))+effect
        groups[key].append((rid,y,r['mechanism_des'],r['function1'],r['function2'],n1,n2))
        status['explicit_role_and_direction' if y is not None else 'unresolved_role_or_direction']+=1
    rows=[]; lineage=[]; exclusions=Counter()
    for key,items in sorted(groups.items()):
        labels={v[1] for v in items}
        if None in labels: reason='unresolved_annotation'
        elif len(labels)>1:reason='conflicting_labels'
        elif len(splits[key])>1:reason='cross_partition'
        else:reason='retained'
        exclusions[reason]+=1
        for rid,y,mech,f1,f2,n1,n2 in items:
            lineage.append((rid,key,assignments[rid],n1,n2,mech,f1,f2,y,reason))
        if reason!='retained':continue
        a,b=key.split('|'); y=labels.pop()
        rows.append(dict(key=key,a=min(smiles[a]),b=min(smiles[b]),y=y,role=y//2,split=next(iter(splits[key]))))
    d=pd.DataFrame(rows)
    assert d.key.is_unique and set(d.y)=={0,1,2,3}
    d.to_csv(OUT/'pairs.csv',index=False)
    pd.DataFrame(lineage,columns=['record','key','source_split','drug1','drug2','mechanism','function1','function2','y','status']).to_csv(OUT/'label_audit.csv.gz',index=False)
    folds={s:np.flatnonzero(d.split==s) for s in ('fit','val','test')}
    np.savez(OUT/'fold0.npz',**folds)
    audit=dict(official_metabolic_rows=len(raw),public_release_records=len(records),assigned_release_records=len(assignments),
               public_metabolic_records=sum(status.values()),record_mapping=status,pair_groups=exclusions,
               split_sizes={s:len(i) for s,i in folds.items()},labels_by_split=d.groupby(['split','y']).size().unstack().to_dict('index'),
               unique_drug_keys=len(set('|'.join(d.key).split('|'))),
               sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [source,RAW/'compact.pkl',RAW/'drugs.csv',RAW/'metabolism.csv',*sorted(RAW.glob('*_seed0.txt'))]})
    (OUT/'audit.json').write_text(json.dumps(audit,indent=2))
    print(json.dumps(audit,indent=2),flush=True)

if __name__=='__main__':main()
