"""Use the same paired four-class evaluation as EVENT_MEDIUM."""
from pathlib import Path
import json
import sys
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT.parent/'event_medium_native'))
from score_event import main
if __name__=='__main__':
    sizes=json.loads((OUT/'audit.json').read_text())['split_sizes']
    main(OUT,sum(sizes.values()),sizes['test'])
