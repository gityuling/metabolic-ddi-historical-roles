"""Fit the MeTDDI architecture using the shared MeTDDI dataset pair manifest."""
import argparse
import hashlib
import json
import time

import numpy as np
import pandas as pd
from train import (OUT, ROOT, SRC, tf, model_for, input_solver, ordered,
                   Mol_Tokenizer, Graph_Bert_Dataset_fine_tune)

MANIFEST = OUT.parent / 'metddi_matched/pairs.csv.gz'
DEST = OUT / 'metddi_matched'
PHASES = (1e-4, 1e-5)
PAD = (0, 0, -1e9, 0, 0, -1e9, 0, 1)


def aligned(model, dataset, size):
    scores = model.predict(dataset, verbose=0)
    assert scores.shape == (size * 2, 4)
    return (scores[:size] + scores[size:, [2, 3, 0, 1]]) / 2


def data_pipeline(frames, tokenizer, seed):
    # Store each molecular graph once. Pad only to each endpoint's batch maximum,
    # as in the released data loader, without caching the full pairs in RAM.
    archive = np.load(ROOT/'MFP-DDI/novel_model/final_suite/met_assets/preprocessed_drug_info.npy',
                      allow_pickle=True).item()
    keys = json.loads((DEST/'graph_keys.json').read_text())
    graph = {name:archive[raw] for name,raw in keys.items()}
    names = sorted(set().union(*(set(f.drug_A) | set(f.drug_B) for f in frames)))
    assert set(names) <= graph.keys()
    encoder = Graph_Bert_Dataset_fine_tune(*frames, tokenizer=tokenizer, batch_size=64, map_dict=graph)
    vectors = []
    for name in names:
        s = tf.constant(name)
        vectors.append(encoder.numerical_seq(s, s, 0)[:16:2])
    fields = []
    lengths = []
    for k, pad in enumerate(PAD):
        items = [np.asarray(v[k], dtype=np.int64 if k == 0 else np.float32) for v in vectors]
        shapes = np.array([x.shape for x in items], dtype=np.int32)
        field = np.full((len(items), *shapes.max(0)), pad, dtype=items[0].dtype)
        for i, arr in enumerate(items):
            field[(i, *(slice(0, n) for n in arr.shape))] = arr
        fields.append(field)
        lengths.append(shapes)
    ids = {s:i for i,s in enumerate(names)}
    dtypes = [tf.as_dtype(field.dtype) for field in fields for _ in range(2)] + [tf.int64]

    def gather(pair_ids, labels):
        buffers = []
        for field, dims in zip(fields, lengths):
            for col in pair_ids.T:
                extents = dims[col].max(0)
                buffers.append(field[(col, *(slice(0,int(n)) for n in extents))])
        return [*buffers, labels[:,None]]

    def fetch(pair_ids, labels):
        tensors = tf.numpy_function(gather, [pair_ids, labels], dtypes)
        for k, field in enumerate(fields):
            for value in tensors[2*k:2*k+2]:
                value.set_shape([None] * field.ndim)
        tensors[-1].set_shape((None,1))
        return input_solver(*tensors)

    def dataset(frame, training):
        pairs = np.column_stack([frame.drug_A.map(ids), frame.drug_B.map(ids)]).astype(np.int32)
        ds = tf.data.Dataset.from_tensor_slices((pairs, frame.DDI.to_numpy(np.int64))).batch(64)
        if training:
            ds = ds.shuffle(512, seed=seed, reshuffle_each_iteration=True)
        return ds.map(fetch, num_parallel_calls=2).prefetch(2)

    # Verify all 16 inputs and targets against the upstream loader on real pairs.
    sample = frames[0].sample(n=64, random_state=31).reset_index(drop=True)
    ref = Graph_Bert_Dataset_fine_tune(sample, sample, sample, tokenizer=tokenizer, batch_size=64,
                                       map_dict=graph).get_data()[0].map(input_solver)
    (ref_x, ref_y), (new_x, new_y) = next(iter(ref)), next(iter(dataset(sample, False)))
    for key in ref_x:
        np.testing.assert_array_equal(ref_x[key].numpy(),new_x[key].numpy())
    np.testing.assert_array_equal(ref_y.numpy(),new_y.numpy())
    return [dataset(f, i==0) for i,f in enumerate(frames)]


def fit(seed):
    tf.keras.utils.set_random_seed(seed)
    assert tf.config.list_physical_devices('GPU'), 'MeTDDI refits require the configured GPU'
    fingerprint = hashlib.sha256(MANIFEST.read_bytes()).hexdigest()
    assert fingerprint == json.loads((MANIFEST.parent/'report.json').read_text())['pair_manifest_sha256']
    pairs = pd.read_csv(MANIFEST)
    assert (pairs.a < pairs.b).all() and not pairs.duplicated(['a', 'b']).any()
    rows = [pairs.loc[pairs.split==k].reset_index(drop=True) for k in ('fit','val','test')]
    assert [len(f) for f in rows] == [155959,8655,6904]
    tokenizer = Mol_Tokenizer(str(SRC/'token_id.json'))
    train, val, test = data_pipeline([ordered(f) for f in rows],tokenizer,seed)
    model = model_for(tokenizer)
    out = DEST/f'seed{seed}'
    out.mkdir(parents=True, exist_ok=True)
    best = out/'best.weights.h5'
    history = []
    best_correct = -1
    best_epoch = 0

    class PairAccuracy(tf.keras.callbacks.Callback):
        def on_epoch_end(self, epoch, logs=None):
            nonlocal best_correct, best_epoch
            p = aligned(self.model, val, len(rows[1]))
            hits = int((p.argmax(1)==rows[1].y.to_numpy()).sum())
            logs['val_pair_accuracy'] = hits/len(rows[1])
            history.append(dict(epoch=len(history)+1, phase=phase+1, validation_correct=hits,
                                validation_accuracy=logs['val_pair_accuracy']))
            if hits > best_correct:
                best_correct, best_epoch = hits,len(history)
                self.model.save_weights(str(best))
            (out/'validation.json').write_text(json.dumps(history,indent=2))
            print('Seed',seed,'epoch',len(history),'aligned validation',hits,'/',len(rows[1]),flush=True)

    start = time.monotonic()
    for phase, rate in enumerate(PHASES):
        model.compile(optimizer=tf.keras.optimizers.Adam(rate),
                      loss=tf.keras.losses.SparseCategoricalCrossentropy())
        model.fit(train,epochs=50,callbacks=[PairAccuracy(),tf.keras.callbacks.EarlyStopping(
            monitor='val_pair_accuracy',mode='max',patience=5)],verbose=2)
    model.load_weights(str(best))
    p = aligned(model,test,len(rows[2]))
    np.testing.assert_allclose(p.sum(1),1,atol=2e-6)
    assert np.isfinite(p).all() and (p>=0).all()
    np.save(out/'predictions.npy',p)
    record = dict(seed=seed, dataset='metddi_matched', train_pairs=len(rows[0]), val_pairs=len(rows[1]),
                  test_pairs=len(rows[2]), manifest_sha256=fingerprint, selected_epoch=best_epoch,
                  selected_validation_correct=best_correct,epochs=len(history), seconds=time.monotonic()-start,
                  tensorflow=tf.__version__, parameters=model.count_params())
    tmp = out/'report.tmp'
    tmp.write_text(json.dumps(record,indent=2))
    tmp.replace(out/'report.json')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('seed',type=int,choices=range(5))
    fit(parser.parse_args().seed)
