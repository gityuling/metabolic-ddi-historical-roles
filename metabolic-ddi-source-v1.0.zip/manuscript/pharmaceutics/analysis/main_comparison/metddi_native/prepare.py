"""Prepare MeTDDI's molecular inputs on the existing within-dataset splits."""
from pathlib import Path
import json
import sys
import numpy as np
import pandas as pd
from rdkit import Chem, RDLogger

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[4]
SRC = ROOT / 'MFP-DDI/novel_model/final_suite/MeTDDI/code/Classification/UnseenDDIs'
sys.path.insert(0, str(SRC))
from utils import Mol_Tokenizer
from dataset_processed import get_adj_matrix, get_dist_matrix, molgraph_rep

RDLogger.DisableLog('rdApp.*')
original = np.load(ROOT / 'MFP-DDI/novel_model/final_suite/met_assets/preprocessed_drug_info.npy', allow_pickle=True).item()
def canonical(s):
    mol = Chem.MolFromSmiles(s)
    if mol is None:
        raise ValueError('Invalid SMILES: ' + s)
    return Chem.MolToSmiles(mol)

cached = {}
for smiles, graph in original.items():
    cached.setdefault(canonical(smiles), graph)
tokenizer = Mol_Tokenizer(str(SRC / 'token_id.json'))
for dataset in ('event_medium_native', 'mecddi_native'):
    df = pd.read_csv(OUT.parent / dataset / 'pairs.csv')
    structures = sorted(set(df.a) | set(df.b))
    graphs = {}
    failures = []
    reused = 0
    for smiles in structures:
        key = canonical(smiles)
        if key in cached:
            graphs[smiles] = cached[key]
            reused += 1
            continue
        try:
            tokens, edges, cliques = tokenizer.tokenize(smiles)
            graphs[smiles] = {'adj_matrix': get_adj_matrix(tokens, edges),
                              'dist_matrix': get_dist_matrix(tokens, edges),
                              'nums_list': tokens, 'edges': edges, 'cliques': cliques,
                              'single_dict': molgraph_rep(smiles, cliques)}
        except Exception as exc:
            failures.append({'smiles': smiles, 'error': repr(exc)})
    report = {'dataset': dataset, 'total': len(structures), 'reused': reused,
              'generated': len(graphs)-reused, 'failures': failures}
    (OUT / f'{dataset}_preprocessing.json').write_text(json.dumps(report, indent=2))
    print(dataset, 'total',len(structures),'reused',reused,'generated',len(graphs)-reused,'failures',len(failures),flush=True)
    if failures:
        print(failures[:5],flush=True)
        continue
    np.save(OUT / f'{dataset}_graphs.npy', graphs)
