"""Train the released MeTDDI architecture on pair-disjoint four-class splits."""
from pathlib import Path
import argparse
import json
import os
import sys
import time
import platform

os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '2')
os.environ.setdefault('TF_NUM_INTRAOP_THREADS', '6')
os.environ.setdefault('TF_NUM_INTEROP_THREADS', '1')
os.environ.setdefault('MPLCONFIGDIR', '/tmp/ddi-metddi-matplotlib')
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[4]
SRC = ROOT / 'MFP-DDI/novel_model/final_suite/MeTDDI/code/Classification/UnseenDDIs'
sys.path.insert(0, str(SRC))
from utils import Mol_Tokenizer
from dataset_processed import Graph_Bert_Dataset_fine_tune
from model_atom_level import EncoderModel_atom
from model_motif_level import EncoderModel_motif, Co_Attention_Layer


def input_solver(*items):
    names = ['molecule_sequence1','molecule_sequence2','adj_matrix1','adj_matrix2',
             'dist_matrix1','dist_matrix2','atom_features1','atom_features2',
             'adjoin_matrix1_atom','adjoin_matrix2_atom','dist_matrix1_atom',
             'dist_matrix2_atom','atom_match_matrix1','atom_match_matrix2','sum_atoms1','sum_atoms2']
    return dict(zip(names, items[:16])), items[16]


def model_for(tokenizer):
    source = (SRC / 'Train_UnseenDDIs.py').read_text()
    begin = source.index("param = {'name': 'Small'")
    end = source.index('models.summary()', begin)
    code = source[begin:end].replace('Dense(d_model/2,', 'Dense(d_model//2,').replace('Dense(d_model/4,', 'Dense(d_model//4,')
    env = dict(tf=tf, Model=Model, Input=Input, EncoderModel_atom=EncoderModel_atom,
               EncoderModel_motif=EncoderModel_motif, Co_Attention_Layer=Co_Attention_Layer,
               tokenizer=tokenizer)
    exec(compile(code, str(SRC / 'Train_UnseenDDIs.py'), 'exec'), env)
    return env['models']


def ordered(frame):
    forward = pd.DataFrame({'drug_A': frame.a, 'drug_B': frame.b, 'DDI': frame.y})
    reverse = pd.DataFrame({'drug_A': frame.b, 'drug_B': frame.a, 'DDI': (frame.y + 2) % 4})
    return pd.concat([forward, reverse], ignore_index=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('dataset', choices=['event_medium_native', 'mecddi_native'])
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--pilot', action='store_true')
    args = ap.parse_args()
    tf.keras.utils.set_random_seed(args.seed)
    data_dir = OUT.parent / args.dataset
    data = pd.read_csv(data_dir / 'pairs.csv')
    split = np.load(data_dir / 'fold0.npz')
    rows = [data.iloc[split[k]].reset_index(drop=True) for k in ('fit','val','test')]
    if args.pilot:
        rows = [rows[0].iloc[:512], rows[1].iloc[:128], rows[2].iloc[:128]]
    frames = [ordered(frame) for frame in rows]
    graph = np.load(OUT / (args.dataset + '_graphs.npy'), allow_pickle=True).item()
    tokenizer = Mol_Tokenizer(str(SRC / 'token_id.json'))
    raw = Graph_Bert_Dataset_fine_tune(*frames, label_field='DDI', tokenizer=tokenizer,
                                       map_dict=graph, batch_size=64).get_data()
    train, val, test = [dataset.map(input_solver, num_parallel_calls=1) for dataset in raw]
    # These are fixed, already-padded tensors. Cache before shuffling to avoid
    # rebuilding 16 graph inputs through Python for every pair in every epoch.
    # Batch contents and the seeded shuffle order are unchanged.
    train = train.cache().shuffle(512, seed=args.seed, reshuffle_each_iteration=True).prefetch(2)
    val = val.cache().prefetch(2)
    model = model_for(tokenizer)
    print('dataset',args.dataset,'seed',args.seed,'pilot',args.pilot,'tf',tf.__version__,
          'GPUs',tf.config.list_physical_devices('GPU'),'parameters',model.count_params(),flush=True)
    folder = OUT / args.dataset / ('pilot' if args.pilot else f'seed{args.seed}')
    folder.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    phases = [(1e-4, 1)] if args.pilot else [(1e-4, 50), (1e-5, 50)]
    runtime = dict(tensorflow=tf.__version__, numpy=np.__version__, python=platform.python_version(),
                   gpu=[device.name for device in tf.config.list_physical_devices('GPU')],
                   parameters=model.count_params(), batch_size=64,
                   phase_learning_rates=[rate for rate, _ in phases],
                   phase_epoch_limits=[epochs for _, epochs in phases],
                   cached_padded_batches=True,
                   early_stopping=dict(patience=5, min_delta=5e-4, monitor='val_loss'))
    (folder/'runtime.json').write_text(json.dumps(runtime, indent=2)+'\n')
    traces = []
    for phase, (rate, epochs) in enumerate(phases):
        model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=rate),
                      loss=tf.keras.losses.SparseCategoricalCrossentropy(),
                      metrics=['sparse_categorical_accuracy'])
        callbacks = [tf.keras.callbacks.ModelCheckpoint(str(folder/f'phase{phase}.weights.h5'),
                        monitor='val_loss', save_best_only=True, save_weights_only=True),
                     tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=5, min_delta=5e-4),
                     tf.keras.callbacks.CSVLogger(str(folder/f'phase{phase}_history.csv'))]
        history = model.fit(train, validation_data=val, epochs=epochs, callbacks=callbacks, verbose=2)
        traces.append({k:[float(x) for x in v] for k,v in history.history.items()})
        # Upstream continues from the final phase-one weights, without restoring its best checkpoint.
    model.load_weights(str(folder/f'phase{len(phases)-1}.weights.h5'))
    p = model.predict(test, verbose=0)
    n = len(rows[2]); assert p.shape == (2*n,4)
    p = (p[:n]+p[n:][:,[2,3,0,1]])/2
    np.save(folder/'predictions.npy',p)
    report={'seed':args.seed,'dataset':args.dataset,'pilot':args.pilot,'train_pairs':len(rows[0]),
            'val_pairs':len(rows[1]),'test_pairs':len(rows[2]),'seconds':time.monotonic()-started,
            'accuracy':float((p.argmax(1)==rows[2].y.to_numpy()).mean()),'history':traces,'runtime':runtime}
    (folder/'report.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({k:v for k,v in report.items() if k!='history'}),flush=True)

if __name__ == '__main__':
    main()
