"""Build the shared MeTDDI test manifest and ordered source-row indices."""
import numpy as np
import pandas as pd
from common import BASE, DIR, canonical, native, reduced

def prepare():
    frames, _ = native()
    seen = set()
    cohorts = []
    for stage, frame in zip(('fit', 'val', 'test'), frames):
        rows = [r for r in reduced(frame) if r[:2] not in seen]
        cohorts.append(pd.DataFrame(rows, columns=['a','b','y']).assign(split=stage))
        seen.update(tuple(sorted((canonical(a),canonical(b)))) for a,b in zip(frame.drug_A, frame.drug_B))
    assert [len(c) for c in cohorts] == [155959,8655,6904]
    fit, val, test = cohorts
    pairs = set(zip(test.a, test.b))
    indices = [i for i,(a,b) in enumerate(zip(frames[2].drug_A,frames[2].drug_B))
               if tuple(sorted((canonical(a),canonical(b)))) in pairs]
    assert len(indices)==2*len(test)
    np.save(BASE/'data/novel_test_indices.npy', np.asarray(indices))
    pd.concat(cohorts).to_csv(DIR/'metddi_matched/pairs.csv.gz',index=False)
    test.assign(source='MeTDDI',role=test.y//2).to_csv(DIR/'scored_pairs.csv',index=False)

if __name__=='__main__':
    prepare()
