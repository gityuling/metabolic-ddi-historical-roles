"""Plot colours sampled from Figures 2 and 3 of the supplied AMP manuscript."""

# Figure 2 uses one series colour for the diagrams, curves, bars and legend.
TEAL = '#117f95'
OCHRE = '#c58b4d'
VIOLET = '#927cb3'
SLATE = '#738694'
MODEL_FILLS = {'Ours': TEAL, 'MFPs': OCHRE, 'IAMV-DDI': VIOLET, 'MeTDDI checkpoint': SLATE}

# Additional control colours from Figure 3.
SKY = '#80b7d5'
NEUTRAL = '#89939e'

INK = '#243e4c'
SECONDARY = '#596e7b'
GRID = '#ecf1f4'
RULE = '#bcc8cf'
PAPER = '#ffffff'

# Light backgrounds for the three ablation symbols.
TEAL_TINT = '#f0f7f8'
SKY_TINT = '#f5f9fb'
OCHRE_TINT = '#fbf7f3'

DATASET_LABELS = {'MeTDDI': 'Dataset 1', 'EVENT_MEDIUM': 'Dataset 2', 'MecDDI': 'Dataset 3'}
