"""Four absolute performance metrics used in the Figure 1 comparison."""
import numpy as np
import pandas as pd

from benchmark_curves import DATASETS, MC, expected_scores


METRICS = ['accuracy', 'macro_f1', 'role_accuracy', 'effect_accuracy']


def benchmark_scores():
    """Return percentage means and sample SDs in dataset order; one run has no SD."""
    fig1_columns = [*METRICS, *(metric + '_seed_sd' for metric in METRICS)]
    summaries = [expected_scores(None)[fig1_columns]]
    for _, _, folder in DATASETS[1:]:
        by_seed = pd.read_csv(MC/folder/'seed_scores.csv')
        metddi = MC/'metddi_native'/folder/'seed_scores.csv'
        if metddi.is_file():
            by_seed = pd.concat([by_seed, pd.read_csv(metddi)], ignore_index=True)
        assert not by_seed.duplicated(['method', 'seed']).any()
        native = by_seed.groupby('method', sort=False)[METRICS]
        assert (native.size() == 5).all()
        means = native.mean()
        np.testing.assert_allclose(means, expected_scores(folder).loc[means.index, METRICS])
        summaries.append(means.join(native.std(ddof=1).add_suffix('_seed_sd')))
    return summaries
