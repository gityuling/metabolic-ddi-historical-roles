"""Draw four-class ROC and PR curves using the locally fitted predictions."""
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
from sklearn.metrics import auc, precision_recall_curve, roc_curve
import comparison_palette as colors
from main_comparison.summarize import metrics

HERE = Path(__file__).resolve().parent
MC = HERE / 'main_comparison'
BASE = HERE.parents[2] / 'MFP-DDI'
MODELS = BASE / 'novel_model'
CHECKPOINT = 'MeTDDI checkpoint'
LINESTYLES = {'Ours': '-', 'MFPs': '--', 'IAMV-DDI': '-.', CHECKPOINT: ':'}
STYLES = {name: (color, LINESTYLES[name]) for name, color in colors.MODEL_FILLS.items()}
DATASETS = [('MeTDDI', 6904, None), ('EVENT_MEDIUM', 4572, 'event_medium_native'),
            ('MecDDI', 5519, 'mecddi_native')]


def both_orders(y, probabilities):
    return np.r_[y, (y+2)%4], np.vstack([probabilities, probabilities[:, [2,3,0,1]]])


def metddi_test_pairs():
    """Return the canonical unordered test cohort in the prediction-archive order."""
    pairs = pd.read_csv(MC/'scored_pairs.csv')
    return pairs.loc[pairs.source.eq('MeTDDI')].reset_index(drop=True)


def metddi_predictions():
    """Yield one order-aligned probability vector per MeTDDI test pair."""
    test = metddi_test_pairs()
    folder = MC/'metddi_matched'
    manifest = pd.read_csv(folder/'pairs.csv.gz').query("split == 'test'").reset_index(drop=True)
    pd.testing.assert_frame_equal(manifest[['a','b','y']],test[['a','b','y']])
    for method, prefix in [('Ours','ours'),('MFPs','mfps'),('IAMV-DDI','predictions')]:
        archive = MC/'iamv_extended' if method=='IAMV-DDI' else folder
        for seed in range(5):
            p = np.load(archive/f'{prefix}{seed}.npy')
            assert p.shape==(len(test),4) and (p>=0).all()
            np.testing.assert_allclose(p.sum(1),1,atol=2e-6)
            yield method,seed,p


def all_metddi_refits():
    yield from metddi_predictions()
    run = MC/'metddi_native/metddi_matched'
    if (run/'direction_summary.json').is_file():
        for seed in range(5):
            yield CHECKPOINT, seed, np.load(run/f'seed{seed}'/'predictions.npy')


def metddi_metrics(test, p):
    values, hits = metrics(test, p)
    increase = p[:, 1] + p[:, 3] > 0.5
    values['effect_accuracy'] = np.mean(increase == test.y.to_numpy() % 2)
    return {name: 100 * value for name, value in values.items()}, hits


def predictions(folder):
    """Yield the same row orientations and seed predictions used by the main comparison."""
    if folder:
        folder = MC / folder
        with np.load(folder/'fold0.npz') as fold:
            test = pd.read_csv(folder/'pairs.csv').iloc[fold['test']]
        assert test.key.is_unique and test.split.eq('test').all()
        for name, stem in [('Ours', 'ours'), ('MFPs', 'mfps'), ('IAMV-DDI', 'iamv')]:
            for seed in range(5):
                yield name, both_orders(test.y.to_numpy(), np.load(folder/'run0'/f'{stem}{seed}.npy'))
        refit = MC/'metddi_native'/folder.name
        if all((refit/f'seed{seed}'/'predictions.npy').is_file() for seed in range(5)):
            for seed in range(5):
                yield CHECKPOINT, both_orders(test.y.to_numpy(), np.load(refit/f'seed{seed}'/'predictions.npy'))
        return

    y = metddi_test_pairs().y.to_numpy()
    for method, _, p in all_metddi_refits():
        yield method, both_orders(y, p)


def macro_curve(curves):
    """Average trapezoidal curves on their joint knots, retaining vertical segments."""
    grid = np.unique(np.concatenate([x for x,_ in curves]))
    total = np.zeros((len(grid),2))
    for x,y in curves:
        knots, first, counts = np.unique(x, return_index=True, return_counts=True)
        left, right = y[first], y[first+counts-1]
        i = np.searchsorted(knots,grid,side='right')-1
        j = np.minimum(i+1,len(knots)-1)
        frac = (grid-knots[i])/np.where(j==i,1,knots[j]-knots[i])
        height = right[i]+frac*(left[j]-right[i])
        pair = np.column_stack([height,height])
        pair[np.searchsorted(grid,knots)] = np.column_stack([left,right])
        total += pair
    mean = total.ravel()/len(curves)
    x = np.repeat(grid,2)
    score = np.mean([auc(a,b) for a,b in curves])
    np.testing.assert_allclose(auc(x,mean),score,atol=1e-8)
    return x,mean,100*score


def expected_scores(folder):
    if folder:
        summary = pd.read_csv(MC/folder/'summary.csv').set_index('method')
        metddi = MC/'metddi_native'/folder/'summary.csv'
        if metddi.is_file():
            summary = pd.concat([summary, pd.read_csv(metddi).set_index('method')])
        return summary
    test = metddi_test_pairs()
    per_seed = pd.DataFrame([
        dict(method=method, **metddi_metrics(test, p)[0]) for method, _, p in all_metddi_refits()
    ])
    groups = per_seed.groupby('method', sort=False)
    return groups.mean().join(groups.std(ddof=1).add_suffix('_seed_sd'))


def dataset_curves(n, folder):
    """Return mean ROC and PR coordinates after matching the archived macro areas."""
    groups = {}
    for name,(y,p) in predictions(folder):
        assert len(y)==2*n and p.shape==(2*n,4)
        np.testing.assert_allclose(p.sum(1),1,atol=2e-6)
        roc,pr = groups.setdefault(name,([],[]))
        for k in range(4):
            fpr,tpr,_ = roc_curve(y==k,p[:,k])
            precision,recall,_ = precision_recall_curve(y==k,p[:,k])
            roc.append((fpr,tpr))
            pr.append((recall[::-1],precision[::-1]))
    expected = expected_scores(folder)
    result = {}
    for name,(roc,pr) in groups.items():
        result[name] = [macro_curve(roc), macro_curve(pr)]
        np.testing.assert_allclose([curve[2] for curve in result[name]],
                                   expected.loc[name,['macro_auroc','macro_aupr']].to_numpy(dtype=float),
                                   rtol=0, atol=1e-5)
    return result


def main():
    out = HERE/'benchmark_curves'
    out.mkdir(exist_ok=True)
    plt.rcParams.update({'svg.fonttype':'none','pdf.fonttype':42,'font.size':10,
                         'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#73848a'})
    fig,axes = plt.subplots(2,3,figsize=(10.5,6.1))
    fig.subplots_adjust(left=.075,right=.98,bottom=.10,top=.81,wspace=.26,hspace=.40)
    handles = [Line2D([],[],color=c,ls=l,lw=2,label=n) for n,(c,l) in STYLES.items()]
    fig.legend(handles=handles,ncol=4,loc='upper center',bbox_to_anchor=(.5,.99),frameon=False)
    for col,(dataset,n,folder) in enumerate(DATASETS):
        curves = dataset_curves(n,folder)
        axes[0,col].set_title(f'{dataset}  ·  {n:,} pairs',fontsize=12,pad=10)
        for row,key in enumerate(['macro_auroc','macro_aupr']):
            ax = axes[row,col]
            ax.set(xlim=(0,1),ylim=(0,1.015),xticks=[0,.5,1],yticks=[0,.5,1])
            ax.set_xlabel('False-positive rate' if row==0 else 'Recall')
            if col==0:
                ax.set_ylabel('True-positive rate' if row==0 else 'Precision')
            zoom=ax.inset_axes([.46,.20,.48,.47])
            zoom.set_facecolor('#f5f8f7')
            if row==0:
                ax.plot([0,1],[0,1],color='#c9cece',ls=':',lw=.8)
                zoom.set(xlim=(0,.05),ylim=(.8,1.002),xticks=[0,.05],yticks=[.8,1])
            else:
                zoom.set(xlim=(.8,1),ylim=(.7,1.004),xticks=[.8,1],yticks=[.7,1])
            zoom.tick_params(labelsize=7,length=2,pad=1)
            for name in reversed(curves):
                x,v,area = curves[name][row]
                c,ls=STYLES[name]
                for target in (ax,zoom):
                    target.plot(x,v,color=c,ls=ls,lw=1.35,clip_on=True)
                if name=='Ours':
                    metric='AUROC' if row==0 else 'AUPR'
                    ax.text(.04,.08,f'{metric} {area/100:.4f}',transform=ax.transAxes,color=c,fontsize=9)
    for ext in ['pdf','svg','png']:
        fig.savefig(out/f'four-class-roc-pr.{ext}',dpi=180)
    plt.close(fig)


if __name__=='__main__':
    main()
